-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 13, 2020 at 04:36 PM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbhospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `appid` int(11) NOT NULL,
  `patid` int(11) NOT NULL,
  `docid` int(11) NOT NULL,
  `appdate` date NOT NULL,
  `apptime` varchar(20) NOT NULL,
  `docfee` double NOT NULL,
  `hoscharge` double NOT NULL,
  `tax` double NOT NULL,
  `totalfee` double NOT NULL,
  `reason` varchar(50) NOT NULL,
  `appstatus` varchar(20) NOT NULL,
  `regdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`appid`, `patid`, `docid`, `appdate`, `apptime`, `docfee`, `hoscharge`, `tax`, `totalfee`, `reason`, `appstatus`, `regdate`) VALUES
(1, 1, 1, '2019-12-16', '10:00 AM', 1000, 200, 24, 1224, 'Fever', 'Visited', '2019-12-04'),
(2, 2, 1, '2020-01-01', '10:00 AM', 1000, 200, 24, 1224, '...', 'Visited', '2019-12-30'),
(3, 2, 1, '2020-01-01', '10:00 AM', 1000, 200, 24, 1224, '...', 'Pending', '2019-12-30'),
(4, 1, 1, '2020-01-14', '10:00 AM', 1000, 300, 26, 1326, '...', 'Cancelled', '2020-01-08'),
(5, 1, 1, '2020-01-13', '10:00 AM', 1000, 200, 24, 1224, '...', 'Pending', '2020-01-08'),
(6, 2, 1, '2020-01-13', '10:00 AM', 1000, 200, 24, 1224, '...', 'Pending', '2020-01-08');

-- --------------------------------------------------------

--
-- Table structure for table `bed`
--

CREATE TABLE `bed` (
  `bedid` int(11) NOT NULL,
  `roomno` varchar(50) NOT NULL,
  `bedno` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bed`
--

INSERT INTO `bed` (`bedid`, `roomno`, `bedno`, `status`) VALUES
(1, 'RM/01', 'RM/01/B-01', 'Available'),
(2, 'RM/01', 'RM/01/B-02', 'Available'),
(3, 'RM/01', 'RM/01/B-03', 'Available'),
(4, 'RM/01', 'RM/01/B-04', 'Available'),
(5, 'RM/01', 'RM/01/B-05', 'Occupied'),
(6, 'RM/02', 'RM/02/B-01', 'Available'),
(7, 'RM/02', 'RM/02/B-02', 'Available'),
(8, 'RM/02', 'RM/02/B-03', 'Available'),
(9, 'RM/02', 'RM/02/B-04', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `diagnosis`
--

CREATE TABLE `diagnosis` (
  `diagid` int(11) NOT NULL,
  `date` varchar(20) NOT NULL,
  `appid` int(11) NOT NULL,
  `diagnosis` varchar(50) NOT NULL,
  `remark` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `diagnosis`
--

INSERT INTO `diagnosis` (`diagid`, `date`, `appid`, `diagnosis`, `remark`) VALUES
(1, '2019-12-22', 1, 'Dengue Fever', 'Rash Fever');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `docid` int(11) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `nic` varchar(20) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `specialist` varchar(30) NOT NULL,
  `status` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `docfee` double NOT NULL,
  `date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`docid`, `fullname`, `gender`, `nic`, `dob`, `contact`, `specialist`, `status`, `username`, `docfee`, `date`) VALUES
(1, 'Mohamed Nifras', 'Male', '982712556V', '1998-09-27', '0757906198', 'Neurologist', 'Active', 'ASCO/DOC/0001', 1000, '2019-11-04'),
(2, 'Mohamed Ajmal', 'Male', '982713556V', '1998-09-27', '0772794984', 'Epidemiologist', 'Active', 'ASCO/DOC/0002', 2000, '2018-12-04'),
(3, 'Mohamed Ramzath', 'Male', '962712556V', '1990-01-16', '0757906198', 'Family Doctor', 'Active', 'ASCO/DOC/0003', 500, '2020-01-08');

-- --------------------------------------------------------

--
-- Table structure for table `doctorpayment`
--

CREATE TABLE `doctorpayment` (
  `paymentid` int(11) NOT NULL,
  `docid` int(11) NOT NULL,
  `appointment` int(11) NOT NULL,
  `total` double NOT NULL,
  `hospitalcut` double NOT NULL,
  `payment` double NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctorpayment`
--

INSERT INTO `doctorpayment` (`paymentid`, `docid`, `appointment`, `total`, `hospitalcut`, `payment`, `date`) VALUES
(1, 1, 1, 1000, 200, 800, '2020-01-05'),
(2, 1, 1, 1000, 200, 800, '2020-01-05'),
(3, 1, 1, 1000, 200, 800, '2020-01-05');

-- --------------------------------------------------------

--
-- Table structure for table `doctorschedule`
--

CREATE TABLE `doctorschedule` (
  `scheduleid` int(11) NOT NULL,
  `docid` int(11) NOT NULL,
  `availableday` varchar(20) NOT NULL,
  `starttime` varchar(10) NOT NULL,
  `endtime` varchar(10) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctorschedule`
--

INSERT INTO `doctorschedule` (`scheduleid`, `docid`, `availableday`, `starttime`, `endtime`, `status`) VALUES
(1, 1, 'Monday', '10:00 AM', '11:00 AM', 'Available'),
(2, 1, 'Tuesday', '11:00 AM', '12:00 PM', 'Available'),
(3, 1, 'Wednesday', '10:59 AM', '10:59 AM', 'Non-Available');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `empid` int(11) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `nic` varchar(20) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `emptype` varchar(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL,
  `dob` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`empid`, `fullname`, `nic`, `gender`, `contact`, `emptype`, `username`, `status`, `dob`) VALUES
(1, 'Mohammed Ajmal', '982712556V', 'Male', '0772794984', 'Front Officer', 'ASCO/OFF/0001', 'Active', '2014-09-27'),
(2, 'John ', '23424432434', 'Male', '0772794984', 'Ward Incharge', 'ASCO/WDI/0002', 'Active', '1998-04-01'),
(3, 'John', '342343434', 'Male', '42342343', 'Ward Incharge', 'ASCO/WDI/0003', 'Active', '2020-01-05'),
(4, 'Mohamed Himas', '962712556V', 'Male', '0772798956', 'Lab Technician', 'ASCO/LAB/0004', 'Active', '2000-01-10'),
(5, 'Ismath Ahamed', '922531466V', 'Male', '0764454554', 'Pharmacist', 'ASCO/PMT/0005', 'Active', '1992-08-10');

-- --------------------------------------------------------

--
-- Table structure for table `ipdadmission`
--

CREATE TABLE `ipdadmission` (
  `id` int(11) NOT NULL,
  `admissionno` varchar(50) NOT NULL,
  `patientid` int(11) NOT NULL,
  `bedid` int(11) NOT NULL,
  `admissiondate` date NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ipdadmission`
--

INSERT INTO `ipdadmission` (`id`, `admissionno`, `patientid`, `bedid`, `admissiondate`, `status`) VALUES
(1, 'ADM/0001', 1, 5, '2019-12-03', 'Discharged'),
(2, 'ADM/0002', 2, 5, '2019-12-03', 'Inward');

-- --------------------------------------------------------

--
-- Table structure for table `ipdbill`
--

CREATE TABLE `ipdbill` (
  `billno` int(11) NOT NULL,
  `admissionno` varchar(20) NOT NULL,
  `roomcharge` double NOT NULL,
  `medcharge` double NOT NULL,
  `trtcharge` double NOT NULL,
  `total` double NOT NULL,
  `billdate` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ipdbill`
--

INSERT INTO `ipdbill` (`billno`, `admissionno`, `roomcharge`, `medcharge`, `trtcharge`, `total`, `billdate`) VALUES
(1, 'ADM/0001', 2250, 0, 0, 2250, '2019-12-08'),
(2, 'ADM/0001', 450, 0, 0, 450, '2019-12-04');

-- --------------------------------------------------------

--
-- Table structure for table `labreport`
--

CREATE TABLE `labreport` (
  `reportid` int(11) NOT NULL,
  `patid` int(11) NOT NULL,
  `reporttype` varchar(50) NOT NULL,
  `result` varchar(100) NOT NULL,
  `remark` varchar(250) NOT NULL,
  `fee` double NOT NULL,
  `date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

CREATE TABLE `medicine` (
  `medid` int(11) NOT NULL,
  `admissionno` varchar(20) NOT NULL,
  `medcine` varchar(50) NOT NULL,
  `fee` double NOT NULL,
  `date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `patid` int(11) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `nic` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `contact` varchar(15) NOT NULL,
  `gender` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`patid`, `fullname`, `nic`, `dob`, `contact`, `gender`) VALUES
(1, 'Mohammed Nifras', '982712556V', '1998-09-27', '0757906198', 'Male'),
(2, 'Mohamed Minhaj', '982712557V', '2000-07-16', '0757906198', 'Male'),
(3, 'Karthika', '962546221V', '1993-06-16', '0779565656', 'Female'),
(4, 'William Carter', '684545455V', '1968-06-12', '0755454545', 'Male');

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE `prescription` (
  `preid` int(11) NOT NULL,
  `appid` int(11) NOT NULL,
  `note` varchar(50) NOT NULL,
  `date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `prescriptiondetails`
--

CREATE TABLE `prescriptiondetails` (
  `id` int(11) NOT NULL,
  `prescid` int(11) NOT NULL,
  `medicine` varchar(50) NOT NULL,
  `instruction` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `roomid` int(11) NOT NULL,
  `wardid` int(11) NOT NULL,
  `roomno` varchar(50) NOT NULL,
  `roomcharge` double NOT NULL,
  `description` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`roomid`, `wardid`, `roomno`, `roomcharge`, `description`) VALUES
(1, 9, 'RM/01', 450, '...'),
(2, 9, 'RM/02', 780, '...');

-- --------------------------------------------------------

--
-- Table structure for table `specialist`
--

CREATE TABLE `specialist` (
  `id` int(11) NOT NULL,
  `doctype` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `specialist`
--

INSERT INTO `specialist` (`id`, `doctype`) VALUES
(1, 'Allergist'),
(2, ' Anaesthesiologist'),
(3, ' Andrologist'),
(4, 'Cardiologist'),
(5, 'Dermatologist'),
(6, ' Endocrinologist'),
(7, 'Epidemiologist'),
(8, 'Family Doctor'),
(9, 'Gastroenterologist'),
(10, 'Hematologist'),
(11, ' Hepatologist'),
(12, 'Immunologist'),
(13, ' Infectious Disease '),
(14, ' Internal Medicine S'),
(15, ' Oral Surgeon'),
(16, ' Medical Examiner'),
(17, ' Medical Geneticist'),
(18, ' Neonatologist'),
(19, 'Nephrologist'),
(20, 'Neurologist'),
(21, 'Neurosurgeon'),
(22, ' Oncologist'),
(23, ' Periodontist'),
(24, ' Pediatrician'),
(25, ' Physiatrist'),
(26, ' Plastic Surgeon'),
(27, ' Psychiatrist'),
(28, ' Radiologist'),
(29, ' Sleep Doctor'),
(30, ' Surgeon'),
(31, ' Urologist'),
(32, ' Vascular Surgeon'),
(33, ' Veterinarian'),
(34, ' Ayurvedic Practione'),
(35, 'Diagnostician'),
(36, ' Homeopathic Doctor'),
(37, ' Microbiologist'),
(38, 'Pharmacist'),
(39, 'Physiotherapist'),
(40, 'Podiatrist / Chiropo');

-- --------------------------------------------------------

--
-- Table structure for table `symptom`
--

CREATE TABLE `symptom` (
  `sympid` int(11) NOT NULL,
  `appid` int(11) NOT NULL,
  `symptom` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `symptom`
--

INSERT INTO `symptom` (`sympid`, `appid`, `symptom`) VALUES
(1, 1, 'Severe headache (mostly in the forehead)'),
(2, 1, 'Body aches and joint pains'),
(3, 1, 'Nausea or vomiting');

-- --------------------------------------------------------

--
-- Table structure for table `treatment`
--

CREATE TABLE `treatment` (
  `trtid` int(11) NOT NULL,
  `admissionno` varchar(50) NOT NULL,
  `treatment` varchar(50) NOT NULL,
  `fee` double NOT NULL,
  `date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `usertype` varchar(20) NOT NULL,
  `saltpassword` varchar(50) NOT NULL,
  `password` varchar(250) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `username`, `usertype`, `saltpassword`, `password`, `date`) VALUES
(1, 'ASCO/DOC/0001', 'Doctor', 'ORi74Z3P#Yfa1MhrUx8q', 'e66c03b5db3e6447f2e0b7c7868f61f7164d0227a5bbd032a3359e22', '2019-12-01'),
(2, 'ASCO/OFF/0001', 'Front Officer', 'ORi74Z3P#Yfa1MhrUx8q', 'e66c03b5db3e6447f2e0b7c7868f61f7164d0227a5bbd032a3359e22', '2019-11-05'),
(3, 'ASCO/DOC/0002', 'Doctor', 'ORi74Z3P#Yfa1MhrUx8q', 'e66c03b5db3e6447f2e0b7c7868f61f7164d0227a5bbd032a3359e22', '2019-12-11'),
(4, 'ASCO/WDI/0003', 'Ward Incharge', 'ORi74Z3P#Yfa1MhrUx8q', 'e66c03b5db3e6447f2e0b7c7868f61f7164d0227a5bbd032a3359e22', '2020-01-05'),
(5, 'ASCO/ADMIN', 'Admin', 'kbaOLTATYMvOzaQT0FDR', '39ae2cd363691bff32cf442260acd62295f9922493d770ea6be76813', '2020-01-07'),
(6, 'ASCO/DOC/0003', 'Doctor', 'txPF9s71@tQviCbGBnh6', 'e1b743160eeaaa53c6f0b972eb7b653a6a7506f1357aa5c24cb5df7e', '2020-01-08'),
(7, 'ASCO/LAB/0004', 'Lab Technician', 'PE7IZTPUBWkhRnrfSOXK', '12c36ba09fcf3276bbbf91dcd600fbc17fb2d43726844d536b5e0e4b', '2020-01-10'),
(8, 'ASCO/PMT/0005', 'Pharmacist', 'OJnD95rV3YXF0LmwwXhR', 'f9b692e46067ca0c1c6cf1e987be057551c7cafbcdd37fa123ed6c46', '2020-01-10');

-- --------------------------------------------------------

--
-- Table structure for table `ward`
--

CREATE TABLE `ward` (
  `wardid` int(11) NOT NULL,
  `wardno` varchar(100) NOT NULL,
  `ward` varchar(100) NOT NULL,
  `description` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ward`
--

INSERT INTO `ward` (`wardid`, `wardno`, `ward`, `description`) VALUES
(9, 'WRD/01', 'General Ward', 'for general patient'),
(10, 'WRD/10', 'Female Ward', '...');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`appid`);

--
-- Indexes for table `bed`
--
ALTER TABLE `bed`
  ADD PRIMARY KEY (`bedid`);

--
-- Indexes for table `diagnosis`
--
ALTER TABLE `diagnosis`
  ADD PRIMARY KEY (`diagid`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`docid`);

--
-- Indexes for table `doctorpayment`
--
ALTER TABLE `doctorpayment`
  ADD PRIMARY KEY (`paymentid`);

--
-- Indexes for table `doctorschedule`
--
ALTER TABLE `doctorschedule`
  ADD PRIMARY KEY (`scheduleid`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`empid`);

--
-- Indexes for table `ipdadmission`
--
ALTER TABLE `ipdadmission`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ipdbill`
--
ALTER TABLE `ipdbill`
  ADD PRIMARY KEY (`billno`);

--
-- Indexes for table `labreport`
--
ALTER TABLE `labreport`
  ADD PRIMARY KEY (`reportid`);

--
-- Indexes for table `medicine`
--
ALTER TABLE `medicine`
  ADD PRIMARY KEY (`medid`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`patid`);

--
-- Indexes for table `prescription`
--
ALTER TABLE `prescription`
  ADD PRIMARY KEY (`preid`);

--
-- Indexes for table `prescriptiondetails`
--
ALTER TABLE `prescriptiondetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`roomid`);

--
-- Indexes for table `specialist`
--
ALTER TABLE `specialist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `symptom`
--
ALTER TABLE `symptom`
  ADD PRIMARY KEY (`sympid`);

--
-- Indexes for table `treatment`
--
ALTER TABLE `treatment`
  ADD PRIMARY KEY (`trtid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `ward`
--
ALTER TABLE `ward`
  ADD PRIMARY KEY (`wardid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `appid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `bed`
--
ALTER TABLE `bed`
  MODIFY `bedid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `diagnosis`
--
ALTER TABLE `diagnosis`
  MODIFY `diagid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `docid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `doctorpayment`
--
ALTER TABLE `doctorpayment`
  MODIFY `paymentid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `doctorschedule`
--
ALTER TABLE `doctorschedule`
  MODIFY `scheduleid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `empid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `ipdadmission`
--
ALTER TABLE `ipdadmission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ipdbill`
--
ALTER TABLE `ipdbill`
  MODIFY `billno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `labreport`
--
ALTER TABLE `labreport`
  MODIFY `reportid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `medicine`
--
ALTER TABLE `medicine`
  MODIFY `medid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `patid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `prescription`
--
ALTER TABLE `prescription`
  MODIFY `preid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `prescriptiondetails`
--
ALTER TABLE `prescriptiondetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `roomid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `specialist`
--
ALTER TABLE `specialist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `symptom`
--
ALTER TABLE `symptom`
  MODIFY `sympid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `treatment`
--
ALTER TABLE `treatment`
  MODIFY `trtid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `ward`
--
ALTER TABLE `ward`
  MODIFY `wardid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;

namespace Hospital_Management_System.Front_Officer
{
    public partial class ucOfficerHome : UserControl
    {
        public ucOfficerHome()
        {
            InitializeComponent();
        }

        Animation animation = new Animation();
        Database database = new Database();

        private async void ucOfficerHome_Load(object sender, EventArgs e)
        {
            lblMessage.Text = "Welcome to the Acesco Hospital Management System, "+User.nameofuser+"!";
            await Task.Delay(1500);
            Task<int> loadTask = loadAsync();
            int result = await loadTask;
        }

        async Task<int> loadAsync()
        {
            animation.textAnimation(lblPatient, database.getOneValue("SELECT COUNT(patid) from patient"));
            animation.textAnimation(lblPending, database.getOneValue("SELECT COUNT(appid) from appointment where appstatus='Pending'"));
            animation.textAnimation(lblVisited, database.getOneValue("SELECT COUNT(appid) from appointment where appstatus='Visited'"));
            animation.textAnimation(lblCancelled, database.getOneValue("SELECT COUNT(appid) from appointment where appstatus='Cancelled'"));

            return 1;
        }
    }
}

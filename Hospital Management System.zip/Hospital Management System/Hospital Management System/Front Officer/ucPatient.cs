﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hospital_Management_System.Front_Officer
{
    public partial class ucPatient : UserControl
    {
        public ucPatient()
        {
            InitializeComponent();
        }

        Database database = new Database();

        string viewQuery = "SELECT `patid`, `fullname`, `nic`, `dob`, `contact`, `gender` FROM `patient` WHERE 1";

        async void loadData(string query)
        {
            dgvPatient.DataSource =await database.GetData(query);
        }

        private void ucPatient_Load(object sender, EventArgs e)
        {
            try
            {
                PublicClass.pnlForm = pnlForm;
                PublicClass.pnlView = pnlView;

                loadData(viewQuery);
                database.showSuggestion("select nic from patient", txtSearch);
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void dgvPatient_DataSourceChanged(object sender, EventArgs e)
        {
            if (dgvPatient.Rows.Count != 0) lblMessage.Visible = false;
            else lblMessage.Visible = true;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dgvPatient.SelectedRows.Count != 0)
            {
                frmPatient patient = new frmPatient();
                patient.dgvPatient = dgvPatient;
                patient.viewQuery = viewQuery;
                patient.mode = false;
                PublicClass.frmControl = patient;
                new Animation().changeView();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            frmPatient patient = new frmPatient();
            patient.dgvPatient = dgvPatient;
            patient.viewQuery = viewQuery;
            patient.mode = true;
            PublicClass.frmControl = patient;
            new Animation().changeView();
        }

        // Show Appoinment form Appointment
        private void btnAddAppointment_Click(object sender, EventArgs e)
        {
            if (dgvPatient.SelectedRows.Count != 0)
            {
                frmAppointment appointment = new frmAppointment();
                appointment.appQuery = viewQuery;
                appointment.mode = true;
                appointment.patid = dgvPatient.SelectedRows[0].Cells[0].Value.ToString();
                PublicClass.frmControl = appointment;
                new Animation().changeView();
            }
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            frmPatientReport report = new frmPatientReport();
            report.reportQuery = viewQuery;
            report.ShowDialog();
        }
    }
}

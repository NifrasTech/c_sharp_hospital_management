﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hospital_Management_System.Front_Officer
{
    public partial class ucOfficerMenu : UserControl
    {
        public ucOfficerMenu()
        {
            InitializeComponent();
        }

        Animation animation = new Animation();

        void activeButton(Button button)
        {
            animation.activeButton(button, lblActive);
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            activeButton(btnHome);
            ucOfficerHome home = new ucOfficerHome();
            animation.loadContent(home, "Dashboard");
        }

        private void btnPatient_Click(object sender, EventArgs e)
        {
            activeButton(btnPatient);
            ucPatient patient = new ucPatient();
            animation.loadContent(patient, "Patient");
        }

        private void btnAppointment_Click(object sender, EventArgs e)
        {
            activeButton(btnAppointment);
            ucAppointment appointment = new ucAppointment();
            animation.loadContent(appointment, "Appointment");
        }

        private void ucOfficerMenu_Load(object sender, EventArgs e)
        {
            btnHome.PerformClick();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            activeButton(button1);
            ucChangePassword changepassword = new ucChangePassword();
            animation.loadContent(changepassword, "Change Password");
        }
    }
}

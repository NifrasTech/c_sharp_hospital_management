﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hospital_Management_System.Front_Officer
{
    public partial class frmPatient : Form
    {
        public frmPatient()
        {
            InitializeComponent();
            validation.numbersOnly(txtContact);
            cmbGender.SelectedIndex = 0;
        }

        Validation validation = new Validation();
        Database database = new Database();
        Animation animation = new Animation();

        public bool mode = true; // if mode is false (Add new) else Update
        public DataGridView dgvPatient;
        public string viewQuery;

        string query, fullname, nic, gender, contact, dob, patid;

        //Patient form Load
        private void frmPatient_Load(object sender, EventArgs e)
        {
            if (mode) btnSave.Text = "SAVE";
            else { getDGVData(); btnSave.Text = "UPDATE"; }
        }

        // Set data from textbox and controls
        void setData()
        {
            fullname = txtName.Text;
            nic = txtNIC.Text;
            gender = cmbGender.Text;
            contact = txtContact.Text;
            dob = dtpDOB.Text;
        }

        // Close the form
        private void btnClose_Click(object sender, EventArgs e)
        {
            new Animation().changeView();
        }

        // Button Save click
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (validation.textBoxEmpty(pnlForm))
                {
                    setData();
                    if (mode) addData();
                    else updateData();
                }
            }
            catch (Exception exc)
            {
                animation.notification(Color.Crimson, "Error", exc.Message);
            }
        }

        // Add New Record
        async void addData()
        {
            try
            {
                query = @"INSERT INTO `patient`(`fullname`, `nic`, `dob`, `contact`, `gender`) VALUES ('"+fullname+ "','" + nic + "','" + dob + "','" + contact + "','" + gender + "')";
                database.ExecuteQry(query);
                dgvPatient.DataSource = await database.GetData(viewQuery);
                animation.notification(Color.SeaGreen, "Success", "Patient Added");
                validation.resetControls(pnlForm);
            }
            catch (Exception exc)
            {
                animation.notification(Color.Crimson, "Error", exc.Message);
            }
        }

        // Edit record
        async void updateData()
        {
            try
            {
                query = "UPDATE `patient` SET `fullname`='" + fullname + "',`nic`='" + nic + "',`dob`='" + dob + "',`contact`='" + contact + "',`gender`='" + gender + "' WHERE patid="+patid;
                database.ExecuteQry(query);
                animation.notification(Color.SeaGreen, "Success", "Patient Record Updated");
                dgvPatient.DataSource =await database.GetData(viewQuery);
                new Animation().changeView();
            }
            catch (Exception exc)
            {
                animation.notification(Color.Crimson, "Error", exc.Message);
            }
        }

        // Get data from gridview
        void getDGVData()
        {
            patid = dgvPatient.SelectedRows[0].Cells[0].Value.ToString();
            txtName.Text = dgvPatient.SelectedRows[0].Cells[1].Value.ToString();
            txtNIC.Text = dgvPatient.SelectedRows[0].Cells[2].Value.ToString();
            cmbGender.Text = dgvPatient.SelectedRows[0].Cells[5].Value.ToString();
            txtContact.Text = dgvPatient.SelectedRows[0].Cells[4].Value.ToString();
            dtpDOB.Text = dgvPatient.SelectedRows[0].Cells[3].Value.ToString();
        }
    }
}

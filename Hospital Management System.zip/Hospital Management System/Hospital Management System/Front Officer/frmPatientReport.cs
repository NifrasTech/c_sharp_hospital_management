﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Front_Officer
{
    public partial class frmPatientReport : Form
    {
        public string reportQuery;
        public frmPatientReport()
        {
            InitializeComponent();
            cmbGender.SelectedIndex = 0;
            validation.numbersOnly(txtEnd);
            validation.numbersOnly(txtStart);
        }

        Database database = new Database();
        Validation validation = new Validation();
        private void picRefresh_Click(object sender, EventArgs e)
        {
            try
            {
                dsPatientBindingSource.DataSource = database.viewData(reportQuery);
                this.reportViewer1.RefreshReport();
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            try
            {
                int start = int.Parse(txtStart.Text);
                int end = int.Parse(txtEnd.Text);

                if (start > end) { txtStart.Text = end.ToString(); txtEnd.Text = start.ToString(); }

                string query = reportQuery + " and YEAR(CURDATE()) - YEAR(dob) BETWEEN " + start + " and " + end + "";

                if (cmbGender.Text == "Male") query = query + " and gender='Male'";
                else if (cmbGender.Text == "Female") query = query + " and gender='Female'";
                dsPatientBindingSource.DataSource = database.viewData(query);
                this.reportViewer1.RefreshReport();
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void frmPatientReport_Load(object sender, EventArgs e)
        {
            try
            {
                dsPatientBindingSource.DataSource = database.viewData(reportQuery);
                this.reportViewer1.RefreshReport();
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

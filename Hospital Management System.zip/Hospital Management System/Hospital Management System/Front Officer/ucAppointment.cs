﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hospital_Management_System.Front_Officer
{
    public partial class ucAppointment : UserControl
    {
        public ucAppointment()
        {
            InitializeComponent();
        }

        Database database = new Database();
        Animation animation = new Animation();

        string viewQuery = "SELECT `appid`, patient.fullname as patientname, TIMESTAMPDIFF(YEAR, patient.dob, CURDATE()) AS age,doctor.fullname as doctorname,doctor.specialist, `appdate`, `totalfee`,`appstatus`,apptime FROM `appointment` INNER join doctor on doctor.docid = appointment.docid INNER join patient on appointment.patid=patient.patid WHERE 1";
        string currentQuery, reportquery;
        async void loadAppointment(string query)
        {
            reportquery = query;
            dgvAppoint.DataSource = await database.GetData(query);

            if (dgvAppoint.Rows.Count != 0) lblMessage.Visible = false;
            else lblMessage.Visible = true;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

        }
        void setQuery()
        {
            if (rbAll.Checked == true) currentQuery = viewQuery;
            else if (rbPending.Checked == true) currentQuery = viewQuery + " and appstatus='Pending'";
            else if (rbCancelled.Checked == true) currentQuery = viewQuery + " and appstatus='Cancelled'";
            else if (rbVisited.Checked == true) currentQuery = viewQuery + " and appstatus='Visited'";
            loadAppointment(currentQuery);
        }
        private void ucAppointment_Load(object sender, EventArgs e)
        {
            setQuery();
        }

        private void rbAll_CheckedChanged(object sender, EventArgs e)
        {
            setQuery();
        }

        private void rbPending_CheckedChanged(object sender, EventArgs e)
        {
            setQuery();
        }

        private void rbVisited_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rbCancelled_CheckedChanged(object sender, EventArgs e)
        {
            setQuery();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string search = txtSearch.Text;
            string query = currentQuery + " and reason like ('%" + search + "%') or apptime like ('%" + search + "%')";
            loadAppointment(query);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (dgvAppoint.SelectedRows.Count != 0)
            {
                string status = dgvAppoint.SelectedRows[0].Cells[7].Value.ToString();
                if (status == "Pending")
                {
                    DialogResult result = MessageBox.Show("Do you want to cancell this appointment?", "Confirmation", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        string query = "UPDATE appointment set appstatus='Cancelled' where appid=" + dgvAppoint.SelectedRows[0].Cells[0].Value.ToString();
                        new Database().ExecuteQry(query);
                        animation.notification(Color.SeaGreen, "Success", "Appointment Cancelled");
                        loadAppointment(currentQuery);
                    }
                }
                else animation.notification(Color.Crimson, "Failed", "Only the Pending appointment can be cancelled");
            }
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            new frmAppointmentReport(reportquery).ShowDialog();
        }
    }
}

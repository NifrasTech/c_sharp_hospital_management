﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;

namespace Hospital_Management_System.Front_Officer
{
    public partial class frmAppointment : Form
    {
        public frmAppointment()
        {
            InitializeComponent();
            validation.numbersOnly(txtTax);
            validation.numbersOnly(txtHosCharge);
        }

        Database database = new Database();
        Validation validation = new Validation();
        DataTable dtable = new DataTable();
        Animation animation = new Animation();

        string docid, appdate, problem,apptime, query;
        public string appQuery,patid;
        double docfee, hoscharge, tax, taxamount, total, grandtotal;
        public bool mode;
        public DataGridView dgvApp;
        string viewQuery = "SELECT `docid`, `fullname`, `specialist`,`docfee` FROM `doctor` WHERE status='Active'";

        #region Get Appoinment Details
        // Edit Tax
        private void cbTax_CheckedChanged(object sender, EventArgs e)
        {
            if (cbTax.Checked == true) txtTax.ReadOnly = false;
            else txtTax.ReadOnly = true;
        }

        // Load Doctor Details
        async void loadDoctor(string query)
        {
            dgvDoctor.DataSource = await database.GetData(query);
            txtPatID.Text = patid; // Set Patient ID
        }

        // Form Shown
        private void frmAppointment_Shown(object sender, EventArgs e)
        {
            try
            {
                if (mode) loadDoctor(viewQuery);
                database.showSuggestion("select nic from patient", txtPatID);
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        // Hospital charge Edit
        private void cbHosCharge_CheckedChanged(object sender, EventArgs e)
        {
            if (cbHosCharge.Checked == true) txtHosCharge.ReadOnly = false;
            else txtHosCharge.ReadOnly = true;
        }

        // Get next date of appointment
        private void cmbDay_SelectedIndexChanged(object sender, EventArgs e)
        {
            DateTime nextDay = new DateTime();
            string day = cmbDay.Text;
            if (day == "Monday") nextDay = GetNextWeekday(DateTime.Today, DayOfWeek.Monday);
            else if (day == "Tuesday") nextDay = GetNextWeekday(DateTime.Today, DayOfWeek.Tuesday);
            else if (day == "Wednesday") nextDay = GetNextWeekday(DateTime.Today, DayOfWeek.Wednesday);
            else if (day == "Thursday") nextDay = GetNextWeekday(DateTime.Today, DayOfWeek.Thursday);
            else if (day == "Friday") nextDay = GetNextWeekday(DateTime.Today, DayOfWeek.Friday);
            else if (day == "Saturday") nextDay = GetNextWeekday(DateTime.Today, DayOfWeek.Saturday);
            else if (day == "Sunday") nextDay = GetNextWeekday(DateTime.Today, DayOfWeek.Sunday);

            lblDate.Text = nextDay.ToShortDateString();
        }

        // Tax Percentage Changed
        private void txtTax_TextChanged(object sender, EventArgs e)
        {
            calculateFee();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {

        }

        // Hospital Charge Changed
        private void txtHosCharge_TextChanged(object sender, EventArgs e)
        {
            calculateFee();
        }

        // Select a Doctor
        private void dgvDoctor_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                if (dgvDoctor.SelectedRows.Count != 0)
                {
                    docid = dgvDoctor.SelectedRows[0].Cells[0].Value.ToString();
                    lblDocFee.Text = dgvDoctor.SelectedRows[0].Cells[3].Value.ToString();
                    loadCombo();
                    calculateFee(); // calculate total fee
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        void loadCombo()
        {
            // First load Day
            // Second Load Schedule time by the Day
            dtable = database.viewData("SELECT `availableday` FROM `doctorschedule` WHERE docid=" + docid);
            if (dtable.Rows.Count != 0)
            {
                btnConfirm.Enabled = true;
                cmbDay.DataSource = dtable;
                cmbDay.DisplayMember = "availableday";
                cmbDay.SelectedIndex = 0;
            }
            else
            {
                animation.notification(Color.Crimson, "Error", "The Doctor Does not have any schedule");
                btnConfirm.Enabled = false;
            }

            dtable = database.viewData("SELECT `starttime` FROM `doctorschedule` WHERE availableday='" + cmbDay.Text + "' and docid=" + docid);
            if (dtable.Rows.Count != 0)
            {
                cmbTime.DataSource = dtable;
                cmbTime.DisplayMember = "starttime";
                cmbTime.ValueMember = "starttime";
                cmbTime.SelectedIndex = 0;
            }
        }

        // Calculate Total Fee
        void calculateFee()
        {
            if (txtHosCharge.Text.Trim() != "" && txtTax.Text.Trim() != "")
            {
                docfee = Convert.ToDouble(lblDocFee.Text);
                hoscharge = Convert.ToDouble(txtHosCharge.Text);
                tax = Convert.ToDouble(txtTax.Text);

                total = docfee + hoscharge;
                taxamount = (total * tax) / 100;
                grandtotal = total + taxamount;
                lblTax.Text = "Rs." + taxamount.ToString();
                lblTotal.Text = "Rs." + grandtotal.ToString();
            }
        }

        // Form Closing
        private void btnClose_Click(object sender, EventArgs e)
        {
            new Animation().changeView();
        }

        // Get Date of the Day
        public static DateTime GetNextWeekday(DateTime start, DayOfWeek day)
        {
            // The (... + 7) % 7 ensures we end up with a value in the range [0, 6]
            int daysToAdd = ((int)day - (int)start.DayOfWeek + 7) % 7;
            return start.AddDays(daysToAdd);
        }
        #endregion

        #region Add Appointment
        // Confirm Appoinment
        private void btnConfirm_Click(object sender, EventArgs e)
        {
            try
            {
                // Set Problem Value (If Empty then filled with dots)
                if (txtProblem.Text.Trim() == "") txtProblem.Text = "...";

                // Check Empty Field
                if (validation.textBoxEmpty(pnlForm))
                {
                    setData(); // Set Data for Appoinment
                    if (checkAvailable()) insertAppoinment();
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        // Set Data for Insert into Appoinment
        void setData()
        {
            appdate = lblDate.Text;
            problem = txtProblem.Text;
            patid = txtPatID.Text;
            apptime = cmbTime.Text;
        }

        // Appoinment Available for a Schedule
        bool checkAvailable()
        {
            query = "select appid from appointment where docid='" + docid + "' and appdate='" + appdate + "' and apptime='" + apptime + "' and patid="+patid+"";
            dtable = database.viewData(query);
            if (dtable.Rows.Count != 0)
            {
                animation.notification(Color.Crimson, "Failed", "The Patient already added");
                return false;
            }
;           query = "select COUNT(appid) from appointment where docid='"+docid+"' and appdate='"+appdate+"' and apptime='"+apptime+"'";
            int result =Convert.ToInt32(database.getOneValue(query));
            if (result > 15)
            {
                animation.notification(Color.Crimson, "Error", "Maximum appointment added");
                return false;
            }
            else return true;
        }

        // Add Appoinment Details
        void insertAppoinment()
        {
            try
            {
                query = @"INSERT INTO `appointment`(`patid`, `docid`, `appdate`,`apptime`,`docfee`, `hoscharge`, `tax`, `totalfee`, `reason`, `appstatus`, `regdate`) 
                VALUES (" + patid + "," + docid + ",'" + appdate + "','" + apptime + "'," + docfee + "," + hoscharge + "," + taxamount + "," + grandtotal + ",'" + problem + "','Pending',CURDATE());";
                database.ExecuteQry(query);
                animation.notification(Color.SeaGreen, "Success", "Appointment Added");
                new Animation().changeView();
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        #endregion
    }
}

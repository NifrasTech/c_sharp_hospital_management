﻿namespace Hospital_Management_System.Front_Officer
{
    partial class ucOfficerHome
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucOfficerHome));
            this.lblVisited = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblPending = new System.Windows.Forms.Label();
            this.lblPatient = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblMessage = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lblCancelled = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblVisited
            // 
            this.lblVisited.BackColor = System.Drawing.Color.SeaGreen;
            this.lblVisited.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblVisited.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblVisited.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVisited.ForeColor = System.Drawing.Color.White;
            this.lblVisited.Image = ((System.Drawing.Image)(resources.GetObject("lblVisited.Image")));
            this.lblVisited.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblVisited.Location = new System.Drawing.Point(58, 288);
            this.lblVisited.Name = "lblVisited";
            this.lblVisited.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lblVisited.Size = new System.Drawing.Size(149, 58);
            this.lblVisited.TabIndex = 92;
            this.lblVisited.Text = "0";
            this.lblVisited.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1.Location = new System.Drawing.Point(49, 348);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.label1.Size = new System.Drawing.Size(172, 23);
            this.label1.TabIndex = 97;
            this.label1.Text = "Visited Appointment";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPending
            // 
            this.lblPending.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblPending.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblPending.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblPending.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPending.ForeColor = System.Drawing.Color.White;
            this.lblPending.Image = ((System.Drawing.Image)(resources.GetObject("lblPending.Image")));
            this.lblPending.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblPending.Location = new System.Drawing.Point(58, 170);
            this.lblPending.Name = "lblPending";
            this.lblPending.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lblPending.Size = new System.Drawing.Size(149, 58);
            this.lblPending.TabIndex = 93;
            this.lblPending.Text = "0";
            this.lblPending.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblPatient
            // 
            this.lblPatient.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblPatient.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblPatient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblPatient.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPatient.ForeColor = System.Drawing.Color.White;
            this.lblPatient.Image = ((System.Drawing.Image)(resources.GetObject("lblPatient.Image")));
            this.lblPatient.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblPatient.Location = new System.Drawing.Point(58, 58);
            this.lblPatient.Name = "lblPatient";
            this.lblPatient.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lblPatient.Size = new System.Drawing.Size(149, 58);
            this.lblPatient.TabIndex = 94;
            this.lblPatient.Text = "0";
            this.lblPatient.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.label5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label5.Location = new System.Drawing.Point(59, 118);
            this.label5.Name = "label5";
            this.label5.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.label5.Size = new System.Drawing.Size(148, 23);
            this.label5.TabIndex = 99;
            this.label5.Text = "No of Patient";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.label2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label2.Location = new System.Drawing.Point(37, 229);
            this.label2.Name = "label2";
            this.label2.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.label2.Size = new System.Drawing.Size(187, 23);
            this.label2.TabIndex = 97;
            this.label2.Text = "Pending Appointment";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMessage
            // 
            this.lblMessage.BackColor = System.Drawing.Color.Gainsboro;
            this.lblMessage.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblMessage.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.ForeColor = System.Drawing.Color.Crimson;
            this.lblMessage.Location = new System.Drawing.Point(0, 0);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(1020, 40);
            this.lblMessage.TabIndex = 100;
            this.lblMessage.Text = "Welcome";
            this.lblMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(547, 170);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(473, 483);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 101;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.label3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label3.Location = new System.Drawing.Point(37, 467);
            this.label3.Name = "label3";
            this.label3.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.label3.Size = new System.Drawing.Size(190, 23);
            this.label3.TabIndex = 97;
            this.label3.Text = "Cancelled Appointment";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCancelled
            // 
            this.lblCancelled.BackColor = System.Drawing.Color.Crimson;
            this.lblCancelled.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblCancelled.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblCancelled.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCancelled.ForeColor = System.Drawing.Color.White;
            this.lblCancelled.Image = ((System.Drawing.Image)(resources.GetObject("lblCancelled.Image")));
            this.lblCancelled.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblCancelled.Location = new System.Drawing.Point(58, 407);
            this.lblCancelled.Name = "lblCancelled";
            this.lblCancelled.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lblCancelled.Size = new System.Drawing.Size(149, 58);
            this.lblCancelled.TabIndex = 92;
            this.lblCancelled.Text = "0";
            this.lblCancelled.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ucOfficerHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.lblCancelled);
            this.Controls.Add(this.lblVisited);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblPending);
            this.Controls.Add(this.lblPatient);
            this.Controls.Add(this.label5);
            this.Name = "ucOfficerHome";
            this.Size = new System.Drawing.Size(1020, 650);
            this.Load += new System.EventHandler(this.ucOfficerHome_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label lblVisited;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblPending;
        private System.Windows.Forms.Label lblPatient;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblCancelled;
    }
}

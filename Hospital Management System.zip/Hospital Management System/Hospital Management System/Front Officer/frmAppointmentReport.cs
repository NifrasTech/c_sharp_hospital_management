﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Front_Officer
{
    public partial class frmAppointmentReport : Form
    {
        public frmAppointmentReport(string query)
        {
            InitializeComponent();
            dsAppointmentBindingSource.DataSource = new Database().viewData(query);
            reportquery = query;
        }
        string reportquery;

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmAppointmentReport_Load(object sender, EventArgs e)
        {
            dtpEnd.MinDate = dtpStart.Value;
            this.reportViewer1.RefreshReport();
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            try
            {
                dsAppointmentBindingSource.DataSource = new Database().viewData(reportquery + " and appdate between '" + dtpStart.Text + "' AND '" + dtpEnd.Text + "'");
                this.reportViewer1.RefreshReport();
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void picRefresh_Click(object sender, EventArgs e)
        {
            dsAppointmentBindingSource.DataSource = new Database().viewData(reportquery);
            this.reportViewer1.RefreshReport();
        }

        private void dtpStart_ValueChanged(object sender, EventArgs e)
        {
            dtpEnd.MinDate = dtpStart.Value;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Pharmacist
{
    public partial class ucPharmacistMenu : UserControl
    {
        public ucPharmacistMenu()
        {
            InitializeComponent();
        }

        Animation animation = new Animation();

        private void btnSetting_Click(object sender, EventArgs e)
        {
            ucChangePassword changepassword = new ucChangePassword();
            animation.loadContent(changepassword, "Change Password");
            animation.activeButton(btnSetting, lblActive);
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            ucPharmacistHome home = new ucPharmacistHome();
            animation.loadContent(home, "Home");
            animation.activeButton(btnHome, lblActive);
        }
    }
}

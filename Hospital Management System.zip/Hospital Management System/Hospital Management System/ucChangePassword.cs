﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System
{
    public partial class ucChangePassword : UserControl
    {
        public ucChangePassword()
        {
            InitializeComponent();
        }

        User user = new User();
        Animation animation = new Animation();

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            user.updatePassword(User.username, txtConfirm.Text);
        }

        private void cbOld_CheckedChanged(object sender, EventArgs e)
        {
            if (cbOld.Checked != true) txtOld.UseSystemPasswordChar = true;
            else txtOld.UseSystemPasswordChar = false;
        }

        private void cbNew_CheckedChanged(object sender, EventArgs e)
        {
            if (cbNew.Checked != true) txtNew.UseSystemPasswordChar = true;
            else txtNew.UseSystemPasswordChar = false;
        }

        private void cbConfirm_CheckedChanged(object sender, EventArgs e)
        {
            if (cbConfirm.Checked != true) txtConfirm.UseSystemPasswordChar = true;
            else txtConfirm.UseSystemPasswordChar = false;
        }

        private void txtOld_TextChanged(object sender, EventArgs e)
        {
            if (user.checkPassword(User.username, txtOld.Text))
            {
                txtNew.Enabled = true;
                txtOld.ForeColor = Color.SeaGreen;
            }
            else
            {
                txtNew.Enabled = false;
                txtConfirm.Enabled = false;
                txtNew.Text = "";
                btnUpdate.Enabled = false;

                txtOld.ForeColor = Color.Crimson;
            }
        }

        private void txtNew_TextChanged(object sender, EventArgs e)
        {
            if (txtNew.Text.Length >= 6)
            {
                txtNew.ForeColor = Color.SeaGreen;
                txtConfirm.Enabled = true;
            }
            else
            {
                txtNew.ForeColor = Color.Crimson;
                txtConfirm.Text = "";
                txtConfirm.Enabled = false;
                btnUpdate.Enabled = false;
            }
        }

        private void txtConfirm_TextChanged(object sender, EventArgs e)
        {
            if (txtConfirm.Text == txtNew.Text)
            {
                txtConfirm.ForeColor = Color.SeaGreen;
                btnUpdate.Enabled = true;
            }
            else
            {
                txtConfirm.ForeColor = Color.Crimson;
                btnUpdate.Enabled = false;
            }
        }
    }
}

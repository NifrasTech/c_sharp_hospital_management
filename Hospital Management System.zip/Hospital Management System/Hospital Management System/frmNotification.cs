﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System
{
    public partial class frmNotification : Form
    {
        public frmNotification(Color color, string content, string title)
        {
            InitializeComponent();
            this.BackColor = color;
            lblContent.Text = content;
            lblTitle.Text = title;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private async void frmNotification_Shown(object sender, EventArgs e)
        {
            await Task.Delay(3000);
            Transitions.Transition trsn = new Transitions.Transition(new Transitions.TransitionType_CriticalDamping(500));
            trsn.add(this, "Top", -Height);
            trsn.run();
            await Task.Delay(1000);
            this.Close();
        }
    }
}

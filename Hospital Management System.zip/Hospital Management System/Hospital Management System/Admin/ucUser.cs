﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hospital_Management_System.Admin
{
    public partial class ucUser : UserControl
    {
        public ucUser()
        {
            InitializeComponent();
            
        }

        Database database = new Database();

        string viewQuery = "SELECT `empid`, `fullname`, `nic`, `gender`, `contact`, `emptype`, `status`, `dob`,username FROM `employee` WHERE 1";

        async void loadData(string query)
        {
            dgvEmployee.DataSource =await database.GetData(query);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            frmUser user = new frmUser();
            user.dgvUser = dgvEmployee;
            user.viewQuery = viewQuery;
            user.mode = true;
            PublicClass.frmControl = user;
            new Animation().changeView();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            frmUser user = new frmUser();
            user.dgvUser = dgvEmployee;
            user.viewQuery = viewQuery;
            user.mode = false;
            PublicClass.frmControl = user;
            new Animation().changeView();
        }

        private void ucUser_Load(object sender, EventArgs e)
        {
            try
            {
                PublicClass.pnlForm = pnlForm;
                PublicClass.pnlView = pnlView;

                loadData(viewQuery);
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void dgvEmployee_DataSourceChanged(object sender, EventArgs e)
        {
            if (dgvEmployee.Rows.Count != 0) lblMessage.Visible = false;
            else lblMessage.Visible = true;
        }
    }
}

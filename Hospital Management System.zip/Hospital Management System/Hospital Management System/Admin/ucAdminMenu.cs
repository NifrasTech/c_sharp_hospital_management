﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;

namespace Hospital_Management_System.Admin
{
    public partial class ucAdminMenu : UserControl
    {
        private delegate void DELEGATE();
        public ucAdminMenu()
        {
            InitializeComponent();
        }

        Animation animation = new Animation();

        void activeButton(Button button)
        {
            animation.activeButton(button,lblActive);
        }

        private void ucAdminMenu_Load(object sender, EventArgs e)
        {
            activeButton(btnHome);
            ucAdminHome doctor = new ucAdminHome();
            animation.loadContent(doctor, "Dashboard");
        }

        private async void btnDoctor_Click(object sender, EventArgs e)
        {
            activeButton(btnDoctor);
            await Task.Run(() =>
            {
                Delegate newdelegate = new DELEGATE(changeControl);
                this.Invoke(newdelegate);
            });
            //Delegate newdelegate = new Delegate(changeControl);
            //Task newtask = changeControl();
            //await newtask;
        }

        void changeControl()
        {
            ucDoctor doctor = new ucDoctor();
            animation.loadContent(doctor, "Doctor");
        }

        private void btnUsers_Click(object sender, EventArgs e)
        {
            activeButton(btnUsers);
            ucUser user = new ucUser();
            animation.loadContent(user, "Users");
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            activeButton(btnHome);
            ucAdminHome home = new ucAdminHome();
            animation.loadContent(home, "Dashboard");
        }

        private void btnSetting_Click(object sender, EventArgs e)
        {
            activeButton(btnSetting);
            ucChangePassword changepassword = new ucChangePassword();
            animation.loadContent(changepassword, "Change Password");
        }

        private void btnDoctorPayment_Click(object sender, EventArgs e)
        {
            activeButton(btnDoctorPayment);
            ucDoctorPayment earning = new ucDoctorPayment();
            animation.loadContent(earning, "Doctor Payment");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Admin
{
    public partial class frmEarning : Form
    {
        public frmEarning()
        {
            InitializeComponent();
        }
        Animation animation = new Animation();

        DataTable dTable = new DataTable();
        public string docid;
        double payment, earning, hospitalcut, appcount;
        async void loadPayment()
        {
            try
            {
                string dateQuery = "SELECT DATE('" + dtpDate.Text + "' + INTERVAL (6 - WEEKDAY('" + dtpDate.Text + "')) DAY) as enddate,SUBDATE('" + dtpDate.Text + "', WEEKDAY('" + dtpDate.Text + "')) as startdate";
                dTable = await new Database().GetData(dateQuery);
                dtpDate.Text = dTable.Rows[0]["startdate"].ToString();
                lblDate.Text = dTable.Rows[0]["enddate"].ToString();

                string paymentQuery = "select doctor.fullname,doctor.specialist,sum(appointment.docfee) as earning, count(appointment.appid) as count, SUM(appointment.docfee)*20/(100) as cut from appointment inner join doctor on doctor.docid = appointment.docid where (appointment.appdate between '"+dtpDate.Text+"' and '"+lblDate.Text+"') and appstatus='Visited' and doctor.docid=" + docid;
                dTable = await new Database().GetData(paymentQuery);
                if (dTable.Rows[0]["count"].ToString()!="0")
                {
                    lblDoctor.Text = dTable.Rows[0]["fullname"].ToString();
                    earning = double.Parse(dTable.Rows[0]["earning"].ToString());
                    appcount = double.Parse(dTable.Rows[0]["count"].ToString());
                    hospitalcut = double.Parse(dTable.Rows[0]["cut"].ToString());
                    payment = double.Parse(dTable.Rows[0]["earning"].ToString()) - double.Parse(dTable.Rows[0]["cut"].ToString());

                    lblPayment.Text = payment.ToString();
                    lblCount.Text = appcount.ToString();
                    lblCut.Text = hospitalcut.ToString();
                    lblEarning.Text = earning.ToString();
                }
                else
                {
                    lblPayment.Text = "Empty";
                    lblEarning.Text = "Empty";
                    lblCount.Text = "Empty";
                    lblCut.Text = "Empty";
                }
            }
            catch (Exception exc) { MessageBox.Show(exc.Message); }
        }

        private void dtpDate_ValueChanged(object sender, EventArgs e)
        {
            loadPayment();
        }

        private void frmEarning_Load(object sender, EventArgs e)
        {
            loadPayment();
            //string day = DateTime.Now.DayOfWeek.ToString();

            ////if (day != "Saturday") btnSettle.Enabled = false;

            //DateTime endDay = DateTime.Now.AddDays((DayOfWeek.Saturday - DateTime.Now.DayOfWeek));
            //DateTime startDay = DateTime.Now.AddDays(DayOfWeek.Sunday - DateTime.Now.DayOfWeek);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            new Animation().changeView();
        }

        private void btnAddPayment_Click(object sender, EventArgs e)
        {
            if (lblCount.Text == "Empty") animation.notification(Color.Crimson, "Error", "Appointments are Empty");
            else
            {
                string checkPayment = "SELECT `paymentid` FROM `doctorpayment` WHERE date = '"+lblDate.Text.Substring(0,10)+"'";
                dTable = new Database().viewData(checkPayment);

                if (dTable.Rows.Count == 0)
                {
                    string insertQuery = @"INSERT INTO `doctorpayment`(`docid`, `appointment`,`total`, `hospitalcut`, `payment`, `date`) 
                values (" + docid + "," + appcount + "," + earning + "," + hospitalcut + "," + payment + ",'" + lblDate.Text + "')";

                    new Database().ExecuteQry(insertQuery);
                }
                else animation.notification(Color.Crimson, "Error", "The payment already added");
            }
        }

        //void 
    }
}

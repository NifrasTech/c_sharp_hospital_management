﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hospital_Management_System.Admin
{
    public partial class frmDoctor : Form
    {
        public frmDoctor()
        {
            InitializeComponent();
            cmbGender.SelectedIndex = 0;
            cmbStatus.SelectedIndex = 0;
            validation.numbersOnly(txtFees);
            validation.numbersOnly(txtContact);
        }

        Validation validation = new Validation();
        Database database = new Database();
        Animation animation = new Animation();

        public bool mode = true; // if mode is false (Add new) else Update
        public DataGridView dgvDoctor;
        public string viewQuery;
        string query, fullname, nic, fees, gender, dob, type, contact, status, docid, password;

        //Show Password
        private void cbShow_CheckedChanged(object sender, EventArgs e)
        {
            if (cbShow.Checked == true) txtPassword.UseSystemPasswordChar = false;
            else txtPassword.UseSystemPasswordChar = true;
        }

        // Set Data from Text Box
        void setData()
        {
            fullname = txtName.Text;
            nic = txtNIC.Text;
            fees = txtFees.Text;
            gender = cmbGender.Text;
            dob = dtpDOB.Text;
            type = txtType.Text;
            contact = txtContact.Text;
            status = cmbStatus.Text;
            password = txtPassword.Text;
        }

        // Form Close
        private void btnClose_Click(object sender, EventArgs e)
        {
            new Animation().changeView();
        }

        // Button Save Click
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (validation.textBoxEmpty(pnlForm))
                {
                    setData();
                    if (mode) addData();
                    else updateData();
                }
                else animation.notification(Color.Crimson,"Error","Fill all EMpty Box");
            }
            catch (Exception exc) { MessageBox.Show(exc.Message); }
        }

        //Add new Record
        async void addData()
        {
            try
            {
                query = @"INSERT INTO `doctor`(`fullname`, `gender`, `nic`, `dob`, `contact`, `specialist`, `status`, username,`docfee`,date) 
                VALUES ('" + fullname + "','" + gender + "','" + nic + "','" + dob + "','" + contact + "','" + type + "','" + status + "','"+txtUsername.Text+"'," + fees + ",CURDATE())";
                database.ExecuteQry(query);
                //dgvDoctor.DataSource =await database.GetData(viewQuery);
                await PublicClass.refreshdata(viewQuery); // load data To datagridview
                new User().createUser(txtUsername.Text, password, "Doctor");
                validation.resetControls(pnlForm);
                cbShow.Checked = false; // Reset Check Box
                animation.notification(Color.SeaGreen, "Success", "Data Added");

                // Insert User Name and Password
                //query = @"INSERT INTO `users`(`username`, `password`, `usertype`) VALUES ('" + txtUsername.Text + "','" + password + "','Doctor')";
                //database.ExecuteQry(query);

            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        // Update Exist Data
        async void updateData()
        {
            try
            {
                query = @"UPDATE `doctor` SET `fullname`='" + fullname + "',`gender`='" + gender + "',`nic`='" + nic + "',`dob`='" + dob + "',`contact`='" + contact + "',`specialist`='" + type + "',`status`='" + status + "',`docfee`=" + fees + " WHERE docid=" + docid;
                database.ExecuteQry(query);
                await PublicClass.refreshdata(viewQuery); // load data To datagridview
                animation.notification(Color.SeaGreen, "Success", "Record Updated");
                //query = "UPDATE users SET password='" + password + "' where username='" + txtUsername.Text + "'";
                //database.ExecuteQry(query);
                new Animation().changeView(); // Close Form
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void frmDoctor_Load(object sender, EventArgs e)
        {
            if (mode)
            {
                btnSave.Text = "Save";
                txtPassword.Text = "password";
                new User().generateUserName(txtUsername,"Doctor");
            }
            else updateRecord();
            database.showSuggestion("SELECT doctype FROM `specialist` ", txtType);
        }

        //Set Textbox value by Datagridview cells
        void updateRecord()
        {
            cmbStatus.Enabled = true;
            docid = dgvDoctor.SelectedRows[0].Cells[0].Value.ToString();
            txtName.Text = dgvDoctor.SelectedRows[0].Cells[1].Value.ToString();
            cmbGender.Text = dgvDoctor.SelectedRows[0].Cells[2].Value.ToString();
            txtNIC.Text = dgvDoctor.SelectedRows[0].Cells[3].Value.ToString();
            dtpDOB.Text = dgvDoctor.SelectedRows[0].Cells[4].Value.ToString();
            txtContact.Text = dgvDoctor.SelectedRows[0].Cells[5].Value.ToString();
            txtType.Text = dgvDoctor.SelectedRows[0].Cells[6].Value.ToString();
            cmbStatus.Text = dgvDoctor.SelectedRows[0].Cells[7].Value.ToString();
            txtFees.Text = dgvDoctor.SelectedRows[0].Cells[8].Value.ToString();
            txtUsername.Text = dgvDoctor.SelectedRows[0].Cells[9].Value.ToString();
            //password = database.getOneValue("select password from users where username='" + txtUsername.Text + "'");
            //txtPassword.Text = password;
            txtPassword.Enabled = false;
            cbShow.Enabled = false;
        }
    }
}

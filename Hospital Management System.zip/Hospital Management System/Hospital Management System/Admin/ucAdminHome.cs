﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;

namespace Hospital_Management_System.Admin
{
    public partial class ucAdminHome : UserControl
    {
        private delegate void DelegateFunc();
        Database database = new Database();
        Animation animation = new Animation();

        public ucAdminHome()
        {
            //Delegate del = new DelegateFunc(InitializeComponent);
            //this.Invoke(del);
            InitializeComponent();
        }

        private async void ucAdminHome_Load(object sender, EventArgs e)
        {
            Task<int> loadTask = loadAsync();
            await Task.Delay(3000);
            int result = await loadTask;
        }

        async Task<int> loadAsync()
        {
            animation.textAnimation(lblDoctor, database.getOneValue("select count(docid) from doctor"));
            animation.textAnimation(lblUser,database.getOneValue("SELECT COUNT(empid) FROM `employee` WHERE 1"));
            animation.textAnimation(lblPatient, database.getOneValue("SELECT COUNT(patient.patid) FROM patient"));
            return 1;
        }
    }
}

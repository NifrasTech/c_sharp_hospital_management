﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hospital_Management_System.Admin
{
    public partial class frmUser : Form
    {
        public frmUser()
        {
            InitializeComponent();
            cmbStatus.SelectedIndex = 0;
            cmbGender.SelectedIndex = 0;
        }

        Validation validation = new Validation();
        Database database = new Database();
        Animation animation = new Animation();

        public bool mode = true; // if mode is false (Add new) else Update
        public DataGridView dgvUser;
        public string viewQuery;

        string query, fullname, nic, gender, type, contact, status, empid, password, dob;

        private void pnlForm_Paint(object sender, PaintEventArgs e)
        {

        }

        private void cmbType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(mode) new User().generateUserName(txtUsername, cmbType.Text);
        }

        // User Load
        private void frmUser_Load(object sender, EventArgs e)
        {
            if (mode)
            {
                cmbType.SelectedIndex = 0;
                btnSave.Text = "SAVE";
                txtPassword.Text = "password";
                new User().generateUserName(txtUsername, cmbType.Text);
            }
            else
            {
                getDGVData();
                btnSave.Text = "UPDATE";
                cmbType.Enabled = false;
                cmbStatus.Enabled = true;
            }
        }

        void setData()
        {
            fullname = txtName.Text;
            nic = txtNIC.Text;
            gender = cmbGender.Text;
            type = cmbType.Text;
            contact = txtContact.Text;
            status = cmbStatus.Text;
            password = txtPassword.Text;
            dob = dtpDOB.Text;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            new Animation().changeView();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (validation.textBoxEmpty(pnlForm))
                {
                    setData();
                    if (mode) addData();
                    else updateData();
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        async void addData()
        {
            try
            {
                query = @"INSERT INTO `employee`(`fullname`, `nic`, `gender`, `contact`, `emptype`, username,`status`, `dob`) 
                VALUES ('" + fullname + "','" + nic + "','" + gender + "','" + contact + "','" + type + "','"+txtUsername.Text+"','" + status + "','" + dob + "')";
                database.ExecuteQry(query);
                dgvUser.DataSource = await database.GetData(viewQuery);
                animation.notification(Color.SeaGreen, "Success", "Record Added");

                //// Insert User Name and Password
                //query = @"INSERT INTO `users`(`username`, `password`, `usertype`) VALUES ('" + txtUsername.Text + "','" + password + "','" + type + "')";
                //database.ExecuteQry(query);

                new User().createUser(txtUsername.Text,password,type);
                validation.resetControls(pnlForm);
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        // Record Update
        async void updateData()
        {
            try
            {
                query = "UPDATE `employee` SET `fullname`='" + fullname + "',`nic`='" + nic + "',`gender`='" + gender + "',`contact`='" + contact + "',`emptype`='" + type + "',`status`='" + status + "',`dob`='" + dob + "' WHERE empid='" + empid + "'";
                database.ExecuteQry(query);
                animation.notification(Color.SeaGreen, "Success", "Record Updated");
                dgvUser.DataSource = await database.GetData(viewQuery);
                //query = "UPDATE users SET passsword='" + password + "' where username='" + txtUsername.Text + "'";
                //database.ExecuteQry(query);
                new Animation().changeView();
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        void getDGVData()
        {
            empid = dgvUser.SelectedRows[0].Cells[0].Value.ToString();
            txtName.Text = dgvUser.SelectedRows[0].Cells[1].Value.ToString();
            txtNIC.Text = dgvUser.SelectedRows[0].Cells[2].Value.ToString();
            cmbGender.Text = dgvUser.SelectedRows[0].Cells[3].Value.ToString();
            txtContact.Text = dgvUser.SelectedRows[0].Cells[4].Value.ToString();
            cmbType.Text = dgvUser.SelectedRows[0].Cells[5].Value.ToString();
            cmbStatus.Text = dgvUser.SelectedRows[0].Cells[6].Value.ToString();
            dtpDOB.Text = dgvUser.SelectedRows[0].Cells[7].Value.ToString();
            txtUsername.Text = dgvUser.SelectedRows[0].Cells[8].Value.ToString();

            //password = database.getOneValue("select password from users where username='" + txtUsername.Text + "'");
            //txtPassword.Text = password;

            txtPassword.Enabled = false;
            cbShow.Enabled = false;
        }

        // Show password 
        private void cbShow_CheckedChanged(object sender, EventArgs e)
        {
            if (cbShow.Checked == true) txtPassword.UseSystemPasswordChar = false;
            else txtPassword.UseSystemPasswordChar = true;
        }
    }
}

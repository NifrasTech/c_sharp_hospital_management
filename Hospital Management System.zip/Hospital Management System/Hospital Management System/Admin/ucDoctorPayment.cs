﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Admin
{
    public partial class ucDoctorPayment : UserControl
    {
        public ucDoctorPayment()
        {
            InitializeComponent();
        }

        //string viewQuery= "select doctor.fullname,doctor.doctortype,sum(appointment.docfee) as earning, count(appointment.appid) as count, SUM(appointment.docfee)*20/(100) as cut from appointment inner join doctor on doctor.docid = appointment.docid where YEARWEEK(appdate, 1) = YEARWEEK(CURDATE(), 1)";
        string viewQuery= @"SELECT `paymentid`,doctor.fullname, doctor.specialist, `appointment` as count,`total`, `hospitalcut` as cut, `payment`, doctorpayment.`date` FROM `doctorpayment` INNER JOIN doctor on doctor.docid = doctorpayment.docid WHERE 1";
        string reportQuery;
        async void loadData(string query)
        {
            reportQuery = query;
            dgvDoctor.DataSource = await new Database().GetData(query);
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string search = txtSearch.Text;
            string query = viewQuery + " and doctor.fullname LIKE ('%" + search + "%') or doctor.doctortype like ('%" + search + "%')";
            loadData(query);
        }

        private void ucDoctorEarning_Load(object sender, EventArgs e)
        {
            loadData(viewQuery);
            DateTime endDay = DateTime.Now.AddDays((DayOfWeek.Saturday - DateTime.Now.DayOfWeek));
            DateTime startDay = DateTime.Now.AddDays(DayOfWeek.Sunday - DateTime.Now.DayOfWeek);
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            new frmPaymentReport(reportQuery).ShowDialog();
        }

        private void btnPayroll_Click(object sender, EventArgs e)
        {

        }
    }
}

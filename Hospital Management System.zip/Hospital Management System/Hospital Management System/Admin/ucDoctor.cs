﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;

namespace Hospital_Management_System.Admin
{
    public partial class ucDoctor : UserControl
    {
        public ucDoctor()
        {
            InitializeComponent();           
        }

        Database database = new Database();
        DataTable dTable = new DataTable();
        Animation animation = new Animation();

        string viewQuery= "SELECT `docid`, `fullname`, `gender`, `nic`, `dob`, `contact`, `specialist`, `status`, `docfee`,username FROM `doctor` WHERE 1";

        // Add New Doctor
        private void btnAdd_Click(object sender, EventArgs e)
        {
            PublicClass.refreshdata = loadData;
            frmDoctor doctor = new frmDoctor();
            doctor.viewQuery = viewQuery;
            doctor.mode = true;
            PublicClass.frmControl=doctor;
            animation.changeView();
        }

        async Task loadData(string query)
        {
            picLoading.Visible = true;
            dgvDoctor.DataSource = await database.GetData(query);

            await Task.Run(() =>
            {
                System.Threading.Thread.Sleep(300);
            });
            picLoading.Visible = false;
        }

        //Show Message If there is no data in the datagridview
        private void dgvDoctor_DataSourceChanged(object sender, EventArgs e)
        {
            try
            {
                if (dgvDoctor.Rows.Count == 0) lblMessage.Visible = true;
                else lblMessage.Visible = false;
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        // Edit Doctor Details
        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dgvDoctor.SelectedRows.Count != 0)
            {
                frmDoctor doctor = new frmDoctor();
                doctor.dgvDoctor = dgvDoctor;
                doctor.viewQuery = viewQuery;
                doctor.mode = false;
                PublicClass.frmControl = doctor;
                animation.changeView();
            }
        }

        //Usercontrol Load
        private async void ucDoctor_Load(object sender, EventArgs e)
        {
            try
            {
                PublicClass.pnlForm = pnlForm;
                PublicClass.pnlView = pnlView;

                Task newTask=loadData(viewQuery);
                await newTask;
            }
            catch (Exception exc)
            {
                picLoading.Visible = false;
                MessageBox.Show(exc.Message);
            }
        }

        private void dgvDoctor_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {


        }
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            searchDoctor(txtSearch.Text);
        }

        async void searchDoctor(string search)
        {
            string query = viewQuery + " and fullname LIKE ('%"+search+ "%') or doctortype like ('%" + search + "%')";
            await loadData(query);
        }

        // Earning Report Every Doctor
        private void btnEarning_Click_1(object sender, EventArgs e)
        {
            if (dgvDoctor.SelectedRows.Count != 0)
            {
                frmEarning earning = new frmEarning();
                earning.docid = dgvDoctor.SelectedRows[0].Cells[0].Value.ToString();
                PublicClass.frmControl = earning;
                animation.changeView();
            }
        }
    }
}

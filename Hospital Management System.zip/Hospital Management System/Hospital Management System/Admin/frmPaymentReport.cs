﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Admin
{
    public partial class frmPaymentReport : Form
    {
        string reportQuery;
        public frmPaymentReport(string query)
        {
            InitializeComponent();
            reportQuery = query;
        }

        private async void frmPaymentReport_Load(object sender, EventArgs e)
        {
            await Task.Delay(500);
            dsDoctorPaymentBindingSource.DataSource =await new Database().GetData(reportQuery);
            this.reportViewer1.RefreshReport();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            try
            {
                dsDoctorPaymentBindingSource.DataSource = new Database().viewData(reportQuery + " and date between '" + dtpStart.Text + "' AND '" + dtpEnd.Text + "'");
                this.reportViewer1.RefreshReport();
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }
    }
}

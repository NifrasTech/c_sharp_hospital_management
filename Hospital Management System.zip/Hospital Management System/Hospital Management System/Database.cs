﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Data;
using System.Threading.Tasks;

namespace Hospital_Management_System
{
    class Database
    {
        string connectionstring = "Server=Localhost;Database=dbhospital;Uid=root;Password='';";
        static MySqlConnection con = new MySqlConnection("Server=Localhost;Database=dbhospital;Uid=root;Password='';");
        DataTable dTable = new DataTable();

        // Execute Query
        public void ExecuteQry(string QRY)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionstring))
            {
                MySqlCommand command = new MySqlCommand(QRY, connection);
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
        }

        // Return Data Table
        public async Task<DataTable> GetData(string QRY)
        {
            DataTable dTable = new DataTable();
            await Task.Run(() =>
            {
                using (MySqlConnection connection = new MySqlConnection(connectionstring))
                {
                    dTable.Clear();
                    connection.Close();
                    MySqlDataAdapter dAdapter = new MySqlDataAdapter(QRY, connection);
                    connection.Open();
                    dAdapter.Fill(dTable);
                    connection.Close();
                }
            });
            return dTable;
        }

        // View Data Without Async
        public DataTable viewData(string QRY)
        {
            DataTable dTable = new DataTable();
            using (MySqlConnection connection = new MySqlConnection(connectionstring))
            {
                dTable.Clear();
                connection.Close();
                MySqlDataAdapter dAdapter = new MySqlDataAdapter(QRY, connection);
                connection.Open();
                dAdapter.Fill(dTable);
                connection.Close();
            }
            return dTable;
        }

        //Show Textbox suggestion
        public async void showSuggestion(string query, TextBox txtBoxs)
        {
            try
            {
                AutoCompleteStringCollection collection = new AutoCompleteStringCollection();
                await Task.Run(() =>
                {
                    using (MySqlConnection connection = new MySqlConnection(connectionstring))
                    {
                        MySqlCommand command = new MySqlCommand(query, connection);
                        connection.Open();
                        MySqlDataReader dataReader;
                        dataReader = command.ExecuteReader();

                        while (dataReader.Read())
                        {
                            collection.Add(dataReader[0].ToString());
                        }
                        dataReader.Close();
                        connection.Close();
                    }
                });
                txtBoxs.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                txtBoxs.AutoCompleteSource = AutoCompleteSource.CustomSource;
                txtBoxs.AutoCompleteCustomSource = collection;
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        // Execute Image Query
        public void executeImageQuery(string query, string parameter, byte[] image)
        {
            if (con.State == ConnectionState.Open) con.Close();
            con.Open();
            MySqlCommand command = new MySqlCommand(query, con);
            MySqlDataReader datareader;
            command.Parameters.Add(new MySqlParameter(parameter, image));
            datareader = command.ExecuteReader();
            con.Close();
        }

        // Get one value without async
        public string getOneValue(string query)
        {
            string value = "";
            dTable = viewData(query);
            if (dTable.Rows.Count != 0) value = dTable.Rows[0][0].ToString();
            else value = "0";
            return value;
        }

        // Get one value with async
        public async Task<string> getSingleValueasync(string query)
        {
            string value = "";
            dTable = await GetData(query);
            if (dTable.Rows.Count != 0) value = dTable.Rows[0][0].ToString();
            else value = "0";
            return value;
        }
    }
}

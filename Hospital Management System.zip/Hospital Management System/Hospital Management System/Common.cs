﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System
{
    class Common
    {

        //public DateTime dateOfWeek(DayOfWeek day)
        //{
        //    DateTime startAtSaturday = DateTime.Now.AddDays((DayOfWeek.Saturday - DateTime.Now.DayOfWeek));
        //    DateTime startAtSunday = DateTime.Now.AddDays(DayOfWeek.Sunday - DateTime.Now.DayOfWeek);
        //}

    }
}

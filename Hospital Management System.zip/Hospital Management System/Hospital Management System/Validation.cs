﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hospital_Management_System
{
    class Validation
    {
        //---------------- Text Box Empty Validation ------------------
        public bool textBoxEmpty(Control form)
        {
            foreach (var ctrl in form.Controls)
            {
                var txtBox = ctrl as TextBox;
                if (txtBox != null)
                {
                    if (txtBox.Text.Trim() == "")
                    {
                        txtBox.Focus();
                        return false;
                    }
                }
            }
            return true;
        }


        //---------------- Text Box that accept only Numbers validation ------------------
        public void numbersOnly(TextBox txtBox)
        {
            var txtKeyPress = new KeyPressEventHandler(textKeyPress);
            txtBox.KeyPress += textKeyPress;
        }

        void textKeyPress(Object sender, KeyPressEventArgs e)
        {
            Char chr = e.KeyChar;
            if (!Char.IsDigit(chr) && chr != 8 && chr != '.')
            {
                e.Handled = true;
            }
        }

        //Reset controls in a from
        public void resetControls(Control form)
        {
            foreach (var ctrl in form.Controls)
            {
                var txtBox = ctrl as TextBox;
                var combo = ctrl as ComboBox;
                var dattime = ctrl as DateTimePicker;

                if (txtBox != null)
                {
                    if (txtBox.Text.Trim() != "") txtBox.Text = "";
                }
                else if (combo != null) combo.SelectedIndex = 0;
                else if (dattime != null) dattime.ResetText();
            }
        }

        //Check DataGrid View Empty or Not
        public void checkDataGrid(DataGridView dataGrid, Label lblMessage)
        {
            dataGrid.DataSourceChanged += delegate (object sender, EventArgs e) { dataGridEmpty(sender, e, lblMessage, dataGrid); };
        }

        void dataGridEmpty(object sender, EventArgs e, Label lblMessage, DataGridView dataGrid)
        {
            if (dataGrid.Rows.Count == 0) lblMessage.Visible = true;
            else lblMessage.Visible = false;
        }
    }
}

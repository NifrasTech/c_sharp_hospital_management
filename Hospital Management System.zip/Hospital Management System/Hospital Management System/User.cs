﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace Hospital_Management_System
{
    class User
    {
        public static Control ctrlMessage, frmLogin;
        public static int doctorID=1;
        //public static string password;
        public static string username, usertype,doctorname,nameofuser;

        DataTable dTable = new DataTable();
        Database database = new Database();
        Animation animation = new Animation();

        public async void showMessage(string message)
        {
            animation.textAnimation(ctrlMessage,message);

            animation.backColorChange(frmLogin,Color.Crimson);
            await Task.Delay(4000);
            animation.textAnimation(ctrlMessage, "");
            animation.backColorChange(frmLogin, Color.Silver);
        }

        // Generate User Name
        public async void generateUserName(TextBox txtUsername, string usertype)
        {
            //            
            //Ward Incharge
            //Lab Technician
            if (usertype != "Doctor")
            {
                dTable = await new Database().GetData("select max(empid) from employee");
            }
            else dTable = await new Database().GetData("select max(docid) from doctor");
            int maxuserid;
            if (dTable.Rows[0][0].ToString() != "") maxuserid = int.Parse(dTable.Rows[0][0].ToString());
            else maxuserid = 0;

            string username="ASCO/";
            string id = String.Format("{0:D4}", maxuserid+1);
            if (usertype == "Front Officer") txtUsername.Text = username += "OFF/" + id;
            else if (usertype == "Pharmacist") txtUsername.Text = username += "PMT/" + id;
            else if (usertype == "Ward Incharge") txtUsername.Text = username += "WDI/" + id;
            else if (usertype == "Lab Technician") txtUsername.Text = username += "LAB/" + id;
            else if (usertype == "Doctor") txtUsername.Text = username += "DOC/" + id;
        }

        // Generate Random Salt Password
        public static string generateRandom(int length)
        {
            Random random = new Random();
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ@#1234567890abcdefghijklmnopqrstuvwxyz";
            return new string(Enumerable.Repeat(chars, length).Select(s => s[random.Next(s.Length)]).ToArray());
        }

        void setDoctorID()
        {
            doctorID = int.Parse(database.getOneValue("select docid from doctor where username='"+username+"'"));
            doctorname = database.getOneValue("select fullname from doctor where username='" + username + "'");
        }

        public bool userStatus()
        {
            if (usertype == "Admin") return true;
            else
            {
                if (usertype != "Doctor")
                {
                    dTable = database.viewData("select status from employee where username='" + username + "' and status='Active'");
                }
                else database.viewData("select status from doctor where username='" + username + "' and status='Active'");

                if (dTable.Rows.Count == 0) { showMessage("Access Denied"); return false; }
                else return true;
            }
        }

        public bool Login(string username, string password)
        {
            // Check User is Exist
            DataTable dTable = database.viewData(@"SELECT `username`,usertype FROM `users` WHERE username='" + username + "'");
            if (dTable.Rows.Count == 0)
            {
                showMessage("Incorrect User Name");
                return false;
            }
            else
            {
                // Check Password is Correct
                if (checkPassword(dTable.Rows[0][0].ToString(), password))
                {
                    User.username = username;
                    User.usertype = dTable.Rows[0][1].ToString();
                    if (usertype == "Doctor") setDoctorID();
                    else nameofuser = database.getOneValue("select fullname from employee where username='" + username + "'");
                    //addLoginHistory(username, "Login Success");
                    return true;
                }
                else
                {
                    showMessage("Incorrect Password");
                    //addLoginHistory(username, "Attempt Failed");
                    return false;
                }
            }
        }

        // Check password is Correct or Not
        public bool checkPassword(string username, string password)
        {
            dTable = database.viewData("SELECT `userid` FROM `users` WHERE password=SHA2(concat('" + password + "',(select saltpassword FROM users where username='" + username + "')),224)");
            if (dTable.Rows.Count == 0) return false;
            else return true;
        }

        // Create New User
        public bool createUser(string username, string password, string usertype)
        {
            try
            {
                    string salt = generateRandom(20);
                    database.ExecuteQry(@"INSERT INTO `users`(`username`, `usertype`, `saltpassword`, `password`, `date`) 
                    VALUES ('" + username + "','" + usertype + "','" + salt + "',SHA2(CONCAT('" + password + "','" + salt + "'),224), CURDATE())");
                    return true;
            }
            catch (Exception exc)
            {
                animation.notification(Color.Crimson, "Error", exc.Message);
                return false;
            }
        }

        // Update Password
        public bool updatePassword(string username, string password)
        {
            try
            {
                string salt = generateRandom(20);
                database.ExecuteQry("UPDATE users SET password=SHA2(concat('" + password + "','" + salt + "'),224), saltpassword='" + salt + "' where username='" + username + "'");
                animation.notification(Color.SeaGreen, "Success", "Password Update");
                return true;
            }
            catch (Exception exc)
            {
                animation.notification(Color.Crimson, "Error", exc.Message);
                return false;
            }
        }
    }
}

﻿namespace Hospital_Management_System
{


    partial class dsWardBill
    {
        partial class dtWardBillDataTable
        {
        }
    }
}

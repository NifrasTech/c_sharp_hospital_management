﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Lab_Tech
{
    public partial class ucLabTechMenu : UserControl
    {
        public ucLabTechMenu()
        {
            InitializeComponent();
        }
        Animation animation = new Animation();

        private void btnSetting_Click(object sender, EventArgs e)
        {
            ucChangePassword changepassword = new ucChangePassword();
            animation.loadContent(changepassword, "Change Password");
            animation.activeButton(btnSetting, lblActive);
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            ucLabReportHome labreport = new ucLabReportHome();
            animation.loadContent(labreport, "Dashboard");
            animation.activeButton(btnHome, lblActive);
        }

        private void ucLabTechMenu_Load(object sender, EventArgs e)
        {
            btnHome.PerformClick();
        }
    }
}

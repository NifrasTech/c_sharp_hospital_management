﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Lab_Tech
{
    public partial class ucLabReportHome : UserControl
    {
        public ucLabReportHome()
        {
            InitializeComponent();
        }

        private void ucLabReport_Load(object sender, EventArgs e)
        {

        }
    }
}

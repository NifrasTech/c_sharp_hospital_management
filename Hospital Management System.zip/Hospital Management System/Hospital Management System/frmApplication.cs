﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Hospital_Management_System.Admin;
using Hospital_Management_System.Front_Officer;
using Hospital_Management_System.Doctor;
using Hospital_Management_System.Ward_Incharge;
using Hospital_Management_System.Pharmacist;
using Hospital_Management_System.Lab_Tech;

namespace Hospital_Management_System
{
    public partial class frmApplication : Form
    {
        public frmApplication()
        {
            InitializeComponent();
            timer1.Start();
            Animation.mainform = this;
        }

        public string menu;
        void setControls()
        {
            pnlContentOne.Size = pnlMain.Size;
            pnlContentTwo.Size = pnlMain.Size;
            pnlContentOne.Location = new Point(0,0);
            pnlContentTwo.Location = new Point(0,0);

            pnlContentTwo.Top = -pnlMain.Height;

            PublicClass.pnlMenu = pnlMenu;
            PublicClass.pnlContentOne = pnlContentOne;
            PublicClass.pnlContentTwo = pnlContentTwo;
            PublicClass.lblTitle = lblTitle;
            lblTitle.Text = "Home";
        }

        Animation animation = new Animation();

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
            new frmLogin().Show();
        }

        private void frmApplication_Load(object sender, EventArgs e)
        {
            setControls();
            
        }

        private void frmApplication_Shown(object sender, EventArgs e)
        {
            

            if (menu == "Admin")
            {
                ucAdminMenu adminMenu = new ucAdminMenu();
                animation.setMenu(adminMenu);
            }
            else if (menu == "Front Officer")
            {
                ucOfficerMenu officermenu = new ucOfficerMenu();
                animation.setMenu(officermenu);
            }
            else if(menu == "Doctor")
            {
                ucDoctorMenu doctorMenu = new ucDoctorMenu();
                animation.setMenu(doctorMenu);
            }
            else if(menu=="Ward Incharge")
            {
                ucInchargeMenu inchargemenu = new ucInchargeMenu();
                animation.setMenu(inchargemenu);
            }
            else if(menu == "Pharmacist")
            {
                ucPharmacistMenu phatmacist = new ucPharmacistMenu();
                animation.setMenu(phatmacist);
            }
            else if(menu== "Lab Technician")
            {
                ucLabTechMenu labtech = new ucLabTechMenu();
                animation.setMenu(labtech);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblDateTime.Text = DateTime.Now.ToString("dddd, dd MMMM yyyy | hh:mm:ss tt");
            //this.Opacity -= .04;
            //this.Top -= 50;
            //if (this.Opacity == 0)
            //{
            //    this.Close();
            //}
        }

        private void label_Click(object sender, EventArgs e)
        {
            //animation.notification();
        }
    }
}

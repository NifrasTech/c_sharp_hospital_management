﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;
using System.Threading;
using System.Diagnostics;

namespace Hospital_Management_System
{
    public partial class frmLogin : Form
    {
        DataTable dTable = new DataTable();
        Database database = new Database();
        public frmLogin()
        {
            InitializeComponent();
            User.ctrlMessage = lblMessage;
            User.frmLogin = this;
        }

        User user = new User();

        private async void frmLogin_Load(object sender, EventArgs e)
        {
            //dTable = await database.GetData("select * from doctor");
            //Debug.WriteLine(dTable.Rows[0][1].ToString());
            //dTable = await database.GetData("select * from users");
            //Debug.WriteLine(dTable.Rows[0][1].ToString());

            txtUserName.Focus();
            await Task.Delay(2000);

            Task<int> loadTask = loadData();
            int result = await loadTask;
        }

        async Task<int> loadData()
        {
            btnDoctor.Text = await new Database().getSingleValueasync("select count(docid) from doctor where status='Active'");
            btnPatient.Text =await new Database().getSingleValueasync("select count(patid) from patient");
            return 1;
        }

        private async void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtPassword.Text.Trim() != "" && txtUserName.Text.Trim() != "")
            {
                picLoading.Visible = true;
                await Task.Delay(2000);

                if (user.Login(txtUserName.Text, txtPassword.Text))
                {
                    frmApplication application = new frmApplication();
                    application.menu = User.usertype;
                    if (user.userStatus())
                    {
                        await Task.Delay(4000);
                        new Validation().resetControls(pnlLogin);
                        application.Show();
                        this.Hide();
                        //picLoading.Visible = false;
                    }
                }
                else txtUserName.Focus();
            }
            else user.showMessage("Provide User Name and Password");
            picLoading.Visible = false;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) btnLogin.PerformClick();
        }

        private void txtUserName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtUserName_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txtUserName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) txtPassword.Focus();
        }
    }
}

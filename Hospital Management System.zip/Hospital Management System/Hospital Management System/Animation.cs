﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Transitions;

namespace Hospital_Management_System
{
    class Animation
    {
        public static Form mainform;

        // Add Controls to the main panel
        public void loadContent(UserControl userControl, string title)
        {
            userControl.Dock = DockStyle.Fill;

            Transition trsn = new Transition(new TransitionType_CriticalDamping(1000));
            if (PublicClass.pnlContentOne.Top == 0)
            {
                PublicClass.pnlContentTwo.Top = -PublicClass.pnlContentTwo.Height;
                PublicClass.pnlContentTwo.Enabled = true;

                PublicClass.pnlContentTwo.Controls.Clear();
                PublicClass.pnlContentTwo.Controls.Add(userControl);

                trsn.add(PublicClass.pnlContentTwo, "Top", 0);
                trsn.add(PublicClass.pnlContentOne, "Top", PublicClass.pnlContentOne.Height);
                trsn.run();
                PublicClass.pnlContentOne.Enabled = false;
            }
            else
            {
                PublicClass.pnlContentOne.Top = -PublicClass.pnlContentTwo.Height;
                PublicClass.pnlContentOne.Enabled = true;

                PublicClass.pnlContentOne.Controls.Clear();
                PublicClass.pnlContentOne.Controls.Add(userControl);

                trsn.add(PublicClass.pnlContentOne, "Top", 0);
                trsn.add(PublicClass.pnlContentTwo, "Top", PublicClass.pnlContentOne.Height);
                trsn.run();
                PublicClass.pnlContentTwo.Enabled = false;
            }
            PublicClass.lblTitle.Text = title;
        }

        // Change View to Form
        public void changeView()
        {
            PublicClass.frmControl.TopLevel = false;
            PublicClass.frmControl.Anchor = AnchorStyles.None;

            PublicClass.frmControl.Left = (PublicClass.pnlForm.Width - PublicClass.frmControl.Width) / 2;
            PublicClass.frmControl.Top = (PublicClass.pnlForm.Height - PublicClass.frmControl.Height) / 2;

            Transition trsn = new Transition(new TransitionType_CriticalDamping(1000));
            if (PublicClass.pnlView.Left == 0)
            {
                PublicClass.pnlForm.Left = -PublicClass.pnlForm.Width;
                PublicClass.pnlForm.Enabled = true;

                PublicClass.pnlForm.Controls.Clear();
                PublicClass.pnlForm.Controls.Add(PublicClass.frmControl);
                PublicClass.frmControl.Show();

                trsn.add(PublicClass.pnlForm, "Left", 0);
                trsn.add(PublicClass.pnlView, "Left", PublicClass.pnlView.Width);
                trsn.run();
                PublicClass.pnlView.Enabled = false;
            }
            else
            {
                PublicClass.pnlView.Enabled = true;

                trsn.add(PublicClass.pnlView, "Left", 0);
                trsn.add(PublicClass.pnlForm, "Left", -PublicClass.pnlForm.Width);
                trsn.run();
                PublicClass.pnlForm.Enabled = false;
            }
        }

        // Set menu Control
        public void setMenu(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            PublicClass.pnlMenu.Controls.Clear();
            PublicClass.pnlMenu.Controls.Add(userControl);
        }

        //Change Position of Active Label Bar
        public void activeButton(Button button, Label lblActive)
        {
            Transition trsn = new Transition(new TransitionType_CriticalDamping(1000));
            lblActive.BringToFront();
            lblActive.Height = button.Height;

            trsn.add(lblActive, "Top", button.Top);
            trsn.run();
        }

        // Vertical Line Active label Bar
        public void activeVerticle(Button button, Label lblActive)
        {
            Transition trsn = new Transition(new TransitionType_CriticalDamping(1000));
            lblActive.BringToFront();
            lblActive.Width = button.Width;

            trsn.add(lblActive, "Left", button.Left);
            trsn.run();
        }

        // Show Notification
        public void notification(Color color, string title, string content)
        {
            Transition trsn = new Transition(new TransitionType_CriticalDamping(1000));

            frmNotification notification = new frmNotification(color,content,title);

            notification.Left = mainform.Width;
            notification.Top = mainform.Height - notification.Height;

            notification.TopLevel = false;
            mainform.Controls.Add(notification);
            notification.BringToFront();
            notification.Show();

            trsn.add(notification, "Left", mainform.Width - notification.Width);
            trsn.run();
        }

        public void textAnimation (Control ctrl,string text)
        {
            Transition trsn = new Transition(new TransitionType_EaseInEaseOut(800));
            trsn.add(ctrl,"Text",text);
            trsn.run();
        }

        public void backColorChange(Control ctrl, Color color)
        {
            Transition trsn = new Transition(new TransitionType_EaseInEaseOut(800));
            trsn.add(ctrl, "BackColor", color);
            trsn.run();
        }
    }
}

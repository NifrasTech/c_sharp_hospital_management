﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Doctor
{
    public partial class ucDocAppoint : UserControl
    {
        public ucDocAppoint()
        {
            InitializeComponent();
        }

        string viewQUery = @"SELECT `appid`, patient.fullname, CONCAT(TIMESTAMPDIFF(YEAR, patient.dob, CURDATE()),' Year') as age,`appdate`, `apptime`,`reason`, `appstatus` FROM `appointment` INNER JOIN patient on appointment.patid = patient.patid WHERE 1 and docid="+User.doctorID;
        string currentQuery;
        async void viewAppointment(string query)
        {
            dgvAppoint.DataSource = await new Database().GetData(query);
            if (dgvAppoint.Rows.Count != 0) lblMessage.Visible = false;
            else lblMessage.Visible = true;
        }

        void setQuery()
        {
            if (rbAll.Checked == true) currentQuery = viewQUery;
            else if (rbPending.Checked == true) currentQuery = viewQUery + " and appstatus='Pending'";
            else if (rbCancelled.Checked == true) currentQuery = viewQUery + " and appstatus='Cancelled'";
            else if (rbVisited.Checked == true) currentQuery = viewQUery + " and appstatus='Visited'";
            viewAppointment(currentQuery);
        }

        private void ucDocAppoint_Load(object sender, EventArgs e)
        {
            PublicClass.pnlView = pnlForm;
            PublicClass.pnlForm = pnlView;
            setQuery();         
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string search=txtSearch.Text;
            string query = currentQuery + " and reason like ('%"+search+"%') or apptime like ('%"+search+"%')";
            viewAppointment(query);
        }

        private void rbAll_CheckedChanged(object sender, EventArgs e)
        {
            setQuery();
        }

        private void rbPending_CheckedChanged(object sender, EventArgs e)
        {
            setQuery();
        }

        private void rbVisited_CheckedChanged(object sender, EventArgs e)
        {
            setQuery();
        }

        private void rbCancelled_CheckedChanged(object sender, EventArgs e)
        {
            setQuery();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (dgvAppoint.SelectedRows.Count != 0)
            {
                string query = "UPDATE appointment set appstatus='Visited' where appid=" + dgvAppoint.SelectedRows[0].Cells[0].Value.ToString();
                new Database().ExecuteQry(query);
                MessageBox.Show("Appointment Visited");
                viewAppointment(currentQuery);
            }
        }

        private void btnDiagnosis_Click(object sender, EventArgs e)
        {
            if (dgvAppoint.SelectedRows.Count != 0)
            {
                string status = dgvAppoint.SelectedRows[0].Cells[6].Value.ToString();

                if (status == "Pending")
                {
                    frmDiagnosis diagnosis = new frmDiagnosis();
                    PublicClass.frmControl = diagnosis;
                    diagnosis.appointid = dgvAppoint.SelectedRows[0].Cells[0].Value.ToString();
                    diagnosis.fullname = dgvAppoint.SelectedRows[0].Cells[1].Value.ToString();
                    diagnosis.age = dgvAppoint.SelectedRows[0].Cells[2].Value.ToString();
                    new Animation().changeView();
                }
                else if(status=="Visited") new Animation().notification(Color.Crimson,"Failed", "The appoinment already visited");
                else new Animation().notification(Color.Crimson, "Failed", "The appoinment already cancelled");
            }
        }
    }
}

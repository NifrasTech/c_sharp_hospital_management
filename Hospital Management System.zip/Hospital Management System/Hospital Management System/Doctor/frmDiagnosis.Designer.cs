﻿namespace Hospital_Management_System.Doctor
{
    partial class frmDiagnosis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDiagnosis));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txtSymptom = new System.Windows.Forms.TextBox();
            this.btnAddSymp = new System.Windows.Forms.Button();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.gbSymptom = new System.Windows.Forms.GroupBox();
            this.dgvSymptom = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnRemoveSymp = new System.Windows.Forms.Button();
            this.gbDiagnosis = new System.Windows.Forms.GroupBox();
            this.txtRemark = new System.Windows.Forms.TextBox();
            this.txtDiagnosis = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblAge = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.gbPrescription = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnRemovePresc = new System.Windows.Forms.Button();
            this.txtNote = new System.Windows.Forms.TextBox();
            this.txtInstruction = new System.Windows.Forms.TextBox();
            this.btnAddPres = new System.Windows.Forms.Button();
            this.txtMedicine = new System.Windows.Forms.TextBox();
            this.dgvPrescription = new System.Windows.Forms.DataGridView();
            this.medicine = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.instruction = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cbPrescription = new System.Windows.Forms.CheckBox();
            this.gbSymptom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSymptom)).BeginInit();
            this.gbDiagnosis.SuspendLayout();
            this.panel1.SuspendLayout();
            this.gbPrescription.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrescription)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtSymptom
            // 
            this.txtSymptom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSymptom.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSymptom.Location = new System.Drawing.Point(22, 24);
            this.txtSymptom.Name = "txtSymptom";
            this.txtSymptom.Size = new System.Drawing.Size(272, 29);
            this.txtSymptom.TabIndex = 9;
            // 
            // btnAddSymp
            // 
            this.btnAddSymp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnAddSymp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddSymp.FlatAppearance.BorderSize = 0;
            this.btnAddSymp.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SeaGreen;
            this.btnAddSymp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddSymp.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddSymp.ForeColor = System.Drawing.Color.White;
            this.btnAddSymp.Image = ((System.Drawing.Image)(resources.GetObject("btnAddSymp.Image")));
            this.btnAddSymp.Location = new System.Drawing.Point(297, 24);
            this.btnAddSymp.Name = "btnAddSymp";
            this.btnAddSymp.Size = new System.Drawing.Size(41, 30);
            this.btnAddSymp.TabIndex = 88;
            this.btnAddSymp.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAddSymp.UseVisualStyleBackColor = false;
            this.btnAddSymp.Click += new System.EventHandler(this.btnAddSymp_Click);
            // 
            // btnConfirm
            // 
            this.btnConfirm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnConfirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnConfirm.FlatAppearance.BorderSize = 0;
            this.btnConfirm.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SeaGreen;
            this.btnConfirm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConfirm.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirm.ForeColor = System.Drawing.Color.White;
            this.btnConfirm.Location = new System.Drawing.Point(790, 494);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(150, 36);
            this.btnConfirm.TabIndex = 89;
            this.btnConfirm.Text = "Confirm";
            this.btnConfirm.UseVisualStyleBackColor = false;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Crimson;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(634, 494);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(150, 36);
            this.btnClose.TabIndex = 89;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // gbSymptom
            // 
            this.gbSymptom.Controls.Add(this.dgvSymptom);
            this.gbSymptom.Controls.Add(this.btnRemoveSymp);
            this.gbSymptom.Controls.Add(this.btnAddSymp);
            this.gbSymptom.Controls.Add(this.txtSymptom);
            this.gbSymptom.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gbSymptom.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbSymptom.Location = new System.Drawing.Point(21, 66);
            this.gbSymptom.Name = "gbSymptom";
            this.gbSymptom.Size = new System.Drawing.Size(358, 249);
            this.gbSymptom.TabIndex = 89;
            this.gbSymptom.TabStop = false;
            this.gbSymptom.Text = "Add Symptom";
            // 
            // dgvSymptom
            // 
            this.dgvSymptom.AllowUserToAddRows = false;
            this.dgvSymptom.AllowUserToDeleteRows = false;
            this.dgvSymptom.AllowUserToResizeColumns = false;
            this.dgvSymptom.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgvSymptom.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvSymptom.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvSymptom.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSymptom.BackgroundColor = System.Drawing.Color.White;
            this.dgvSymptom.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvSymptom.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvSymptom.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSymptom.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvSymptom.ColumnHeadersHeight = 35;
            this.dgvSymptom.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvSymptom.ColumnHeadersVisible = false;
            this.dgvSymptom.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1});
            this.dgvSymptom.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dgvSymptom.EnableHeadersVisualStyles = false;
            this.dgvSymptom.GridColor = System.Drawing.Color.White;
            this.dgvSymptom.Location = new System.Drawing.Point(22, 59);
            this.dgvSymptom.MultiSelect = false;
            this.dgvSymptom.Name = "dgvSymptom";
            this.dgvSymptom.ReadOnly = true;
            this.dgvSymptom.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSymptom.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvSymptom.RowHeadersVisible = false;
            this.dgvSymptom.RowHeadersWidth = 43;
            this.dgvSymptom.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvSymptom.RowTemplate.Height = 30;
            this.dgvSymptom.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSymptom.Size = new System.Drawing.Size(316, 147);
            this.dgvSymptom.TabIndex = 107;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DividerWidth = 1;
            this.dataGridViewTextBoxColumn1.FillWeight = 80F;
            this.dataGridViewTextBoxColumn1.HeaderText = "Symptom";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // btnRemoveSymp
            // 
            this.btnRemoveSymp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnRemoveSymp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRemoveSymp.FlatAppearance.BorderSize = 0;
            this.btnRemoveSymp.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Crimson;
            this.btnRemoveSymp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRemoveSymp.Font = new System.Drawing.Font("Calibri", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemoveSymp.ForeColor = System.Drawing.Color.White;
            this.btnRemoveSymp.Location = new System.Drawing.Point(232, 212);
            this.btnRemoveSymp.Name = "btnRemoveSymp";
            this.btnRemoveSymp.Size = new System.Drawing.Size(106, 30);
            this.btnRemoveSymp.TabIndex = 88;
            this.btnRemoveSymp.Text = "Remove";
            this.btnRemoveSymp.UseVisualStyleBackColor = false;
            this.btnRemoveSymp.Click += new System.EventHandler(this.btnRemoveSymp_Click);
            // 
            // gbDiagnosis
            // 
            this.gbDiagnosis.Controls.Add(this.txtRemark);
            this.gbDiagnosis.Controls.Add(this.txtDiagnosis);
            this.gbDiagnosis.Controls.Add(this.label1);
            this.gbDiagnosis.Controls.Add(this.label3);
            this.gbDiagnosis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gbDiagnosis.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbDiagnosis.Location = new System.Drawing.Point(21, 317);
            this.gbDiagnosis.Name = "gbDiagnosis";
            this.gbDiagnosis.Size = new System.Drawing.Size(358, 213);
            this.gbDiagnosis.TabIndex = 90;
            this.gbDiagnosis.TabStop = false;
            this.gbDiagnosis.Text = "Add Diagnosis";
            // 
            // txtRemark
            // 
            this.txtRemark.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtRemark.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemark.Location = new System.Drawing.Point(95, 84);
            this.txtRemark.Multiline = true;
            this.txtRemark.Name = "txtRemark";
            this.txtRemark.Size = new System.Drawing.Size(255, 114);
            this.txtRemark.TabIndex = 9;
            this.txtRemark.Text = "...";
            // 
            // txtDiagnosis
            // 
            this.txtDiagnosis.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDiagnosis.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiagnosis.Location = new System.Drawing.Point(96, 33);
            this.txtDiagnosis.Name = "txtDiagnosis";
            this.txtDiagnosis.Size = new System.Drawing.Size(255, 29);
            this.txtDiagnosis.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(-2, 82);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 23);
            this.label1.TabIndex = 105;
            this.label1.Text = "Remark :";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(-2, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 23);
            this.label3.TabIndex = 104;
            this.label3.Text = "Diagnosis :";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gainsboro;
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.lblDate);
            this.panel1.Controls.Add(this.lblAge);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.lblName);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(943, 60);
            this.panel1.TabIndex = 91;
            // 
            // label8
            // 
            this.label8.Dock = System.Windows.Forms.DockStyle.Right;
            this.label8.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(757, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 60);
            this.label8.TabIndex = 109;
            this.label8.Text = "Date :";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDate
            // 
            this.lblDate.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblDate.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(817, 0);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(126, 60);
            this.lblDate.TabIndex = 108;
            this.lblDate.Text = "Date";
            this.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblAge
            // 
            this.lblAge.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblAge.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAge.Location = new System.Drawing.Point(438, 0);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(173, 60);
            this.lblAge.TabIndex = 107;
            this.lblAge.Text = "Age";
            this.lblAge.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.Dock = System.Windows.Forms.DockStyle.Left;
            this.label5.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(379, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 60);
            this.label5.TabIndex = 106;
            this.label5.Text = "Age : ";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblName
            // 
            this.lblName.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblName.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(120, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(259, 60);
            this.lblName.TabIndex = 105;
            this.lblName.Text = "Name";
            this.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Left;
            this.label2.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 60);
            this.label2.TabIndex = 105;
            this.label2.Text = "Patient Name :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // gbPrescription
            // 
            this.gbPrescription.Controls.Add(this.label11);
            this.gbPrescription.Controls.Add(this.label10);
            this.gbPrescription.Controls.Add(this.label9);
            this.gbPrescription.Controls.Add(this.btnRemovePresc);
            this.gbPrescription.Controls.Add(this.txtNote);
            this.gbPrescription.Controls.Add(this.txtInstruction);
            this.gbPrescription.Controls.Add(this.btnAddPres);
            this.gbPrescription.Controls.Add(this.txtMedicine);
            this.gbPrescription.Controls.Add(this.dgvPrescription);
            this.gbPrescription.Enabled = false;
            this.gbPrescription.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gbPrescription.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbPrescription.Location = new System.Drawing.Point(401, 90);
            this.gbPrescription.Name = "gbPrescription";
            this.gbPrescription.Size = new System.Drawing.Size(539, 398);
            this.gbPrescription.TabIndex = 90;
            this.gbPrescription.TabStop = false;
            this.gbPrescription.Text = "Add Prescription";
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(7, 364);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 23);
            this.label11.TabIndex = 105;
            this.label11.Text = "Note :";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(7, 73);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(98, 23);
            this.label10.TabIndex = 105;
            this.label10.Text = "Instruction :";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(7, 26);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(98, 23);
            this.label9.TabIndex = 105;
            this.label9.Text = "Medicine :";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnRemovePresc
            // 
            this.btnRemovePresc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnRemovePresc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRemovePresc.FlatAppearance.BorderSize = 0;
            this.btnRemovePresc.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Crimson;
            this.btnRemovePresc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRemovePresc.Font = new System.Drawing.Font("Calibri", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemovePresc.ForeColor = System.Drawing.Color.White;
            this.btnRemovePresc.Location = new System.Drawing.Point(461, 69);
            this.btnRemovePresc.Name = "btnRemovePresc";
            this.btnRemovePresc.Size = new System.Drawing.Size(72, 30);
            this.btnRemovePresc.TabIndex = 88;
            this.btnRemovePresc.Text = "Remove";
            this.btnRemovePresc.UseVisualStyleBackColor = false;
            this.btnRemovePresc.Click += new System.EventHandler(this.btnRemovePresc_Click);
            // 
            // txtNote
            // 
            this.txtNote.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNote.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNote.Location = new System.Drawing.Point(73, 358);
            this.txtNote.Name = "txtNote";
            this.txtNote.Size = new System.Drawing.Size(460, 29);
            this.txtNote.TabIndex = 9;
            this.txtNote.Text = "...";
            // 
            // txtInstruction
            // 
            this.txtInstruction.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtInstruction.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInstruction.Location = new System.Drawing.Point(111, 70);
            this.txtInstruction.Name = "txtInstruction";
            this.txtInstruction.Size = new System.Drawing.Size(300, 29);
            this.txtInstruction.TabIndex = 9;
            // 
            // btnAddPres
            // 
            this.btnAddPres.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnAddPres.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddPres.FlatAppearance.BorderSize = 0;
            this.btnAddPres.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SeaGreen;
            this.btnAddPres.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddPres.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddPres.ForeColor = System.Drawing.Color.White;
            this.btnAddPres.Image = ((System.Drawing.Image)(resources.GetObject("btnAddPres.Image")));
            this.btnAddPres.Location = new System.Drawing.Point(417, 69);
            this.btnAddPres.Name = "btnAddPres";
            this.btnAddPres.Size = new System.Drawing.Size(41, 30);
            this.btnAddPres.TabIndex = 88;
            this.btnAddPres.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAddPres.UseVisualStyleBackColor = false;
            this.btnAddPres.Click += new System.EventHandler(this.btnAddPres_Click);
            // 
            // txtMedicine
            // 
            this.txtMedicine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMedicine.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMedicine.Location = new System.Drawing.Point(111, 23);
            this.txtMedicine.Name = "txtMedicine";
            this.txtMedicine.Size = new System.Drawing.Size(387, 29);
            this.txtMedicine.TabIndex = 9;
            // 
            // dgvPrescription
            // 
            this.dgvPrescription.AllowUserToAddRows = false;
            this.dgvPrescription.AllowUserToDeleteRows = false;
            this.dgvPrescription.AllowUserToResizeColumns = false;
            this.dgvPrescription.AllowUserToResizeRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgvPrescription.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvPrescription.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvPrescription.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPrescription.BackgroundColor = System.Drawing.Color.White;
            this.dgvPrescription.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPrescription.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvPrescription.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPrescription.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvPrescription.ColumnHeadersHeight = 35;
            this.dgvPrescription.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvPrescription.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.medicine,
            this.instruction});
            this.dgvPrescription.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dgvPrescription.EnableHeadersVisualStyles = false;
            this.dgvPrescription.GridColor = System.Drawing.Color.White;
            this.dgvPrescription.Location = new System.Drawing.Point(5, 107);
            this.dgvPrescription.MultiSelect = false;
            this.dgvPrescription.Name = "dgvPrescription";
            this.dgvPrescription.ReadOnly = true;
            this.dgvPrescription.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPrescription.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvPrescription.RowHeadersVisible = false;
            this.dgvPrescription.RowHeadersWidth = 43;
            this.dgvPrescription.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvPrescription.RowTemplate.Height = 30;
            this.dgvPrescription.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPrescription.Size = new System.Drawing.Size(529, 240);
            this.dgvPrescription.TabIndex = 106;
            // 
            // medicine
            // 
            this.medicine.HeaderText = "Medicine";
            this.medicine.Name = "medicine";
            this.medicine.ReadOnly = true;
            // 
            // instruction
            // 
            this.instruction.HeaderText = "Instruction";
            this.instruction.Name = "instruction";
            this.instruction.ReadOnly = true;
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.cbPrescription);
            this.panel2.Controls.Add(this.gbPrescription);
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Controls.Add(this.gbDiagnosis);
            this.panel2.Controls.Add(this.gbSymptom);
            this.panel2.Controls.Add(this.btnConfirm);
            this.panel2.Controls.Add(this.btnClose);
            this.panel2.Location = new System.Drawing.Point(38, 47);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(945, 543);
            this.panel2.TabIndex = 92;
            // 
            // cbPrescription
            // 
            this.cbPrescription.AutoSize = true;
            this.cbPrescription.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbPrescription.Location = new System.Drawing.Point(832, 72);
            this.cbPrescription.Name = "cbPrescription";
            this.cbPrescription.Size = new System.Drawing.Size(105, 23);
            this.cbPrescription.TabIndex = 92;
            this.cbPrescription.Text = "Prescription";
            this.cbPrescription.UseVisualStyleBackColor = true;
            this.cbPrescription.CheckedChanged += new System.EventHandler(this.cbPrescription_CheckedChanged);
            // 
            // frmDiagnosis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1020, 654);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmDiagnosis";
            this.Text = "frmDiagnosis";
            this.Load += new System.EventHandler(this.frmDiagnosis_Load);
            this.gbSymptom.ResumeLayout(false);
            this.gbSymptom.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSymptom)).EndInit();
            this.gbDiagnosis.ResumeLayout(false);
            this.gbDiagnosis.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.gbPrescription.ResumeLayout(false);
            this.gbPrescription.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrescription)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TextBox txtSymptom;
        public System.Windows.Forms.Button btnAddSymp;
        public System.Windows.Forms.Button btnConfirm;
        public System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.GroupBox gbSymptom;
        public System.Windows.Forms.Button btnRemoveSymp;
        private System.Windows.Forms.GroupBox gbDiagnosis;
        private System.Windows.Forms.TextBox txtDiagnosis;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtRemark;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox gbPrescription;
        public System.Windows.Forms.Button btnRemovePresc;
        public System.Windows.Forms.Button btnAddPres;
        private System.Windows.Forms.TextBox txtMedicine;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtInstruction;
        private System.Windows.Forms.DataGridView dgvPrescription;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtNote;
        private System.Windows.Forms.DataGridView dgvSymptom;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridViewTextBoxColumn medicine;
        private System.Windows.Forms.DataGridViewTextBoxColumn instruction;
        private System.Windows.Forms.CheckBox cbPrescription;
    }
}
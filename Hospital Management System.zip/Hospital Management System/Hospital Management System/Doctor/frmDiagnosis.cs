﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Doctor
{
    public partial class frmDiagnosis : Form
    {
        public frmDiagnosis()
        {
            InitializeComponent();
        }

        public string age,fullname,appointid;

        string prescid;

        DataTable dTable = new DataTable();
        Animation animation = new Animation();

        void onload()
        {
            lblDate.Text = DateTime.Now.ToShortDateString();
            lblAge.Text = age;
            lblName.Text = fullname;
        }

        // Close This Form
        private void btnClose_Click(object sender, EventArgs e)
        {
            new Animation().changeView();
        }

        // Add Symptom
        private void btnAddSymp_Click(object sender, EventArgs e)
        {
            if (txtSymptom.Text.Trim() != "")
            {
                dgvSymptom.Rows.Add(txtSymptom.Text);
                txtSymptom.ResetText();
            }
            else txtSymptom.Focus();
        }

        // Remove Symptom
        private void btnRemoveSymp_Click(object sender, EventArgs e)
        {
            if (dgvSymptom.SelectedRows.Count != 0) dgvSymptom.Rows.RemoveAt(dgvSymptom.CurrentRow.Index);
        }

        // Add Prescription
        private void btnAddPres_Click(object sender, EventArgs e)
        {
            if (txtMedicine.Text.Trim() != "" && txtInstruction.Text.Trim() != "")
            {
                dgvPrescription.Rows.Add(txtMedicine.Text.Trim(), txtInstruction.Text.Trim());
                txtInstruction.ResetText();
                txtMedicine.ResetText();
            }
        }

        // Remmove Prescription
        private void btnRemovePresc_Click(object sender, EventArgs e)
        {
            if (dgvPrescription.SelectedRows.Count != 0) dgvPrescription.Rows.RemoveAt(dgvPrescription.CurrentRow.Index);
        }

        // Check Box Prescription
        private void cbPrescription_CheckedChanged(object sender, EventArgs e)
        {
            if (cbPrescription.Checked == false) gbPrescription.Enabled = false;
            else gbPrescription.Enabled = true;
        }

        // Finalize Diagnosis
        private void btnConfirm_Click(object sender, EventArgs e)
        {
            try
            {
                // Symptom validation
                if (dgvSymptom.Rows.Count == 0) animation.notification(Color.Crimson, "Failed", "You didn't add any symptom");
                else
                {
                    if (addDiagnosis())
                    {
                        insertSymptom();
                        if (cbPrescription.Checked == true) addPrescription();
                        animation.notification(Color.SeaGreen, "Success", "Diagnosis Added");
                        //Close after confirmation
                        new Animation().changeView();
                    }
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        // Add Prescription to the database
        async void addPrescription()
        {
            try
            {
                new Database().ExecuteQry(@"INSERT INTO `prescription`(`appid`, `note`, `date`) 
            VALUES (" + appointid + ",'" + txtNote.Text + "',CURDATE())");

                dTable = await new Database().GetData("select max(preid) from prescription");
                prescid = dTable.Rows[0][0].ToString();
                foreach (DataGridViewRow row in dgvPrescription.Rows)
                {
                    string medicine = row.Cells[0].Value.ToString();
                    string instruction = row.Cells[1].Value.ToString();
                    new Database().ExecuteQry("INSERT INTO `prescriptiondetails`(`prescid`, `medicine`, `instruction`) VALUES (" + prescid + ",'" + medicine + "','" + instruction + "')");
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        // Insert Symptom
        void insertSymptom()
        {
            try
            {
                foreach (DataGridViewRow row in dgvSymptom.Rows)
                {
                    string symptom = row.Cells[0].Value.ToString();
                    new Database().ExecuteQry("INSERT INTO `symptom`(`appid`, `symptom`) VALUES (" + appointid + ",'" + symptom + "')");
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        //Insert Diagnosis
        bool addDiagnosis()
        {
            try
            {
                if (txtDiagnosis.Text.Trim() != "")
                {
                    //Check Precription added
                    if (cbPrescription.Checked == true)
                    {
                        if (dgvPrescription.Rows.Count == 0)
                        {
                            MessageBox.Show("Your Prescription is Empty");
                            return false;
                        }
                    }
                    new Database().ExecuteQry(@"INSERT INTO `diagnosis`(`date`, `appid`,`diagnosis`, `remark`) 
                VALUES (CURDATE()," + appointid + ",'" + txtDiagnosis.Text + "','"+txtRemark.Text+"')");
                    return true;
                }
                else animation.notification(Color.Crimson, "Failed", "Fill Diagnosis");
                return false;
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
                return false;
            }
        }
        // Form Load
        private void frmDiagnosis_Load(object sender, EventArgs e)
        {
            onload();
        }
    }
}

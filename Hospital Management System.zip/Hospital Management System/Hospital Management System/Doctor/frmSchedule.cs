﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hospital_Management_System.Doctor
{
    public partial class frmSchedule : Form
    {
        public frmSchedule()
        {
            InitializeComponent();
            cmbStatus.SelectedIndex = 0;
            cmbDay.SelectedIndex = 0;
        }

        Database database = new Database();
        Animation animation = new Animation();

        public bool mode;
        public DataGridView dgvSchedule;
        public string viewQuery;

        string day, starttime, endtime, status,scheduleid;

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dtpStart_ValueChanged(object sender, EventArgs e)
        {
            dtpEnd.Value = dtpStart.Value.AddHours(1);
        }

        void setData()
        {
            starttime = dtpStart.Text;
            endtime = dtpEnd.Text;
            status = cmbStatus.Text;
            day = cmbDay.Text;
        }

        private async void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                setData();
                if (mode)
                {
                    database.ExecuteQry("INSERT INTO `doctorschedule`(`docid`, `availableday`, `starttime`, `endtime`, `status`) VALUES (1,'" + day + "','" + starttime + "','" + endtime + "','" + status + "')");
                    animation.notification(Color.SeaGreen, "Success", "Record Added");
                }
                else
                {
                    database.ExecuteQry("UPDATE `doctorschedule` SET `availableday`='" + day + "',`starttime`='" + starttime + "',`endtime`='" + endtime + "',`status`='" + status + "' WHERE scheduleid=" + scheduleid);
                    animation.notification(Color.SeaGreen, "Success", "Record Updated");
                }
                dgvSchedule.DataSource = await database.GetData(viewQuery);
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void frmSchedule_Load(object sender, EventArgs e)
        {
            if (!mode) getData(); // Get Data From Data Grid
            dtpEnd.Value = dtpStart.Value.AddHours(1);
        }

        void getData()
        {
            btnAdd.Text = "Update";
            scheduleid = dgvSchedule.SelectedRows[0].Cells[0].Value.ToString();
            cmbDay.Text = dgvSchedule.SelectedRows[0].Cells[1].Value.ToString();
            dtpStart.Text = dgvSchedule.SelectedRows[0].Cells[2].Value.ToString();
            dtpEnd.Text = dgvSchedule.SelectedRows[0].Cells[3].Value.ToString();
            cmbStatus.Text = dgvSchedule.SelectedRows[0].Cells[4].Value.ToString();
        }
    }
}

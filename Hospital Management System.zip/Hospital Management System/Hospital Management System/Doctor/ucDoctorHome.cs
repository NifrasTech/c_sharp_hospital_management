﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;

namespace Hospital_Management_System.Doctor
{
    public partial class ucDoctorHome : UserControl
    {
        public ucDoctorHome()
        {
            InitializeComponent();
        }

        Database database = new Database();
        Animation animation = new Animation();

        private async void ucDoctorHome_Load(object sender, EventArgs e)
        {
            lblMessage.Text = "Welcome Dr."+User.doctorname;
            await Task.Delay(2000);
            Task<int> loadTask = loadAsync();
            int result = await loadTask;
        }

        async Task<int> loadAsync()
        {
            animation.textAnimation(lblToday, database.getOneValue("SELECT COUNT(appid) from appointment where appdate=CURDATE() and docid="+User.doctorID));
            animation.textAnimation(lblPending, database.getOneValue("SELECT COUNT(appid) from appointment where appstatus='Pending' and appdate=CURDATE() and docid="+User.doctorID));
            animation.textAnimation(lblVisited, database.getOneValue("SELECT COUNT(appid) from appointment where appstatus='Visited' and docid=" + User.doctorID));
            animation.textAnimation(lblCancelled, database.getOneValue("SELECT COUNT(appid) from appointment where appstatus='Cancelled' and docid=" + User.doctorID));
            animation.textAnimation(lblMonth, database.getOneValue("SELECT COUNT(appid) from appointment where MONTH(appdate)=MONTH(CURDATE()) and docid=" + User.doctorID));
            animation.textAnimation(lblTotal, database.getOneValue("SELECT COUNT(appid) from appointment where appdate=CURDATE() and docid=" + User.doctorID));

            return 1;
        }
    }
}

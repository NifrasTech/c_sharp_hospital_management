﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Doctor
{
    public partial class ucPatientHistory : UserControl
    {
        public ucPatientHistory()
        {
            InitializeComponent();
        }

        Animation animation = new Animation();
        Database database = new Database();

        void initLoad()
        {
            pnlDiag.Visible = false;
            pnlLab.Visible = false;
            pnlPrescription.Visible = true;
        }

        async void loadData(string patID)
        {
            try
            {
                DataTable dTable = new DataTable();
                dTable = await database.GetData(@"select fullname, TIMESTAMPDIFF(YEAR, dob, CURDATE()) from patient where patid=" + patID);
                lblID.Text = patID;
                lblPatname.Text = dTable.Rows[0][0].ToString();
                lblAge.Text = dTable.Rows[0][1].ToString() + " Year";

                dgvPrescription.DataSource = await database.GetData(@"select preid,prescription.date,doctor.fullname as doctor,diagnosis.diagnosis, note from prescription INNER JOIN appointment on appointment.appid = prescription.appid INNER JOIN doctor on doctor.docid = appointment.docid INNER JOIN diagnosis ON diagnosis.appid = appointment.appid where appointment.patid=" + patID);
                dgvDiagnosis.DataSource = await database.GetData(@"select diagnosis.appid,diagid, diagnosis.date, doctor.fullname as doctor,diagnosis,remark from diagnosis INNER JOIN appointment on diagnosis.appid = appointment.appid INNER JOIN doctor on appointment.docid = doctor.docid where appointment.patid=" + patID);
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        // Find The Patient
        void findPatient()
        {
            try
            {
                string id = database.getOneValue("select ifnull(patid,0) from patient where nic='" + txtSearch.Text + "'");
                if (id == "0") MessageBox.Show("Patient ID is Incorrect");
                else loadData(id);
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        public bool found = false;
        public string patID;

        // Form Load
        private void ucPatientHistory_Load(object sender, EventArgs e)
        {
            initLoad();
            if (found) loadData(patID); // Request from Doctor Patient Form

            // Text Box NIC No suggestion
            database.showSuggestion("select nic from patient", txtSearch);
        }

        // Diagnosis
        private void btnDiagnosis_Click(object sender, EventArgs e)
        {
            pnlLab.Visible = false;
            pnlPrescription.Visible = false;
            pnlDiag.Visible = true;

            animation.activeVerticle(btnDiagnosis, lblActive);
        }

        // Lab Report
        private void btnLabReport_Click(object sender, EventArgs e)
        {
            pnlLab.Visible = true;
            pnlPrescription.Visible = false;
            pnlDiag.Visible = false;

            animation.activeVerticle(btnLabReport, lblActive);
        }

        // Prescription
        private void btnPrescription_Click(object sender, EventArgs e)
        {
            pnlLab.Visible = false;
            pnlPrescription.Visible = true;
            pnlDiag.Visible = false;

            animation.activeVerticle(btnPrescription, lblActive);
        }

        // Patient Textbox key down
        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) findPatient();
        }

        private void txtSearch_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {

        }

        private async void dgvDiagnosis_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                if (dgvDiagnosis.SelectedRows.Count != 0)
                {
                    int appid = int.Parse(dgvDiagnosis.SelectedRows[0].Cells[0].Value.ToString());
                    dgvSymptom.DataSource = await database.GetData("SELECT symptom FROM `symptom` where appid=" + appid);
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private async void dgvPrescription_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                if (dgvPrescription.SelectedRows.Count != 0)
                {
                    int preid = int.Parse(dgvPrescription.SelectedRows[0].Cells[0].Value.ToString());
                    dgvDetails.DataSource = await database.GetData("SELECT `medicine`, `instruction` FROM `prescriptiondetails` WHERE prescid=" + preid);
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void dgvDetails_SelectionChanged(object sender, EventArgs e)
        {
            dgvDetails.ClearSelection();
        }

        private void dgvSymptom_SelectionChanged(object sender, EventArgs e)
        {
            dgvSymptom.ClearSelection();
        }

        private void dgvDiagnosis_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

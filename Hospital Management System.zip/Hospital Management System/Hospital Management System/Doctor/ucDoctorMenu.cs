﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hospital_Management_System.Doctor
{
    public partial class ucDoctorMenu : UserControl
    {
        public ucDoctorMenu()
        {
            InitializeComponent();
        }

        Animation animation = new Animation();

        private void btnSchedule_Click(object sender, EventArgs e)
        {
            ucSchedule schedule = new ucSchedule();
            animation.activeButton(btnSchedule,lblActive);
            animation.loadContent(schedule, "Time Schedule");
        }

        private void btnAppointment_Click(object sender, EventArgs e)
        {
            animation.activeButton(btnAppointment, lblActive);
            ucDocAppoint appoint = new ucDocAppoint();
            animation.loadContent(appoint, "Appointment");
        }

        private void btnPatient_Click(object sender, EventArgs e)
        {
            animation.activeButton(btnPatient, lblActive);
            ucDocPatient patient = new ucDocPatient();
            animation.loadContent(patient, "My Patient");
        }

        private void btnSetting_Click(object sender, EventArgs e)
        {
            animation.activeButton(btnSetting,lblActive);
            ucChangePassword changepassword = new ucChangePassword();
            animation.loadContent(changepassword, "Change Password");
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            animation.activeButton(btnHome, lblActive);
            ucDoctorHome home = new ucDoctorHome();
            animation.loadContent(home,"Dashboard");
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {
            animation.activeButton(btnHistory, lblActive);
            ucPatientHistory history = new ucPatientHistory();
            animation.loadContent(history, "Patient History");
        }

        private void ucDoctorMenu_Load(object sender, EventArgs e)
        {
            btnHome.PerformClick();
        }
    }
}

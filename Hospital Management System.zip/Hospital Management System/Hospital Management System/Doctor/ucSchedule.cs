﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;

namespace Hospital_Management_System.Doctor
{
    public partial class ucSchedule : UserControl
    {
        public ucSchedule()
        {
            InitializeComponent();
            validation.checkDataGrid(dgvSchedule, lblMessage);
        }

        string viewQuery = "SELECT `scheduleid`,`availableday`, `starttime`, `endtime`, `status` FROM `doctorschedule` WHERE 1";
        Validation validation = new Validation();
        Database database = new Database();

        DataTable dTable = new DataTable();

        async void loadData(string query)
        {
           dgvSchedule.DataSource = await database.GetData(query);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            frmSchedule schedule = new frmSchedule();
            schedule.mode = true;
            schedule.viewQuery = viewQuery;
            schedule.dgvSchedule = dgvSchedule;
            schedule.ShowDialog();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            frmSchedule schedule = new frmSchedule();
            schedule.mode = false;
            schedule.viewQuery = viewQuery;
            schedule.dgvSchedule = dgvSchedule;
            schedule.ShowDialog();
        }

        private void ucSchedule_Load(object sender, EventArgs e)
        {
            try
            {
                loadData(viewQuery);
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void dgvSchedule_DataSourceChanged(object sender, EventArgs e)
        {
            //if (dgvSchedule.Rows.Count == 0) lblMessage.Visible = true;
            //else lblMessage.Visible = false;
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            string id = dgvSchedule.SelectedRows[0].Cells[0].Value.ToString();
            database.ExecuteQry("DELETE FROM `doctorschedule` WHERE scheduleid"+id);
            loadData(viewQuery);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Doctor
{
    public partial class ucDocPatient : UserControl
    {
        public ucDocPatient()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

        }

        string viewQuery = "SELECT `patid`, `fullname`, CONCAT(TIMESTAMPDIFF(YEAR, dob, CURDATE()),' Year') as age,`nic`, `dob`, `contact`, `gender` FROM `patient` WHERE 1";

        async void loadData(string query)
        {
            dgvPatient.DataSource = await new Database().GetData(query);
        }

        private void ucDocPatient_Load(object sender, EventArgs e)
        {
            try
            {
                PublicClass.pnlView = pnlPatient;
                PublicClass.pnlForm = pnlDiagnosis;

                loadData(viewQuery);

                //Suggestion text

                new Database().showSuggestion("select nic from patient", txtSearch);
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {

        }

        private void dgvPatient_DataSourceChanged(object sender, EventArgs e)
        {
            if (dgvPatient.Rows.Count == 0) lblMessage.Visible = true;
            else lblMessage.Visible = false;
        }
    }
}

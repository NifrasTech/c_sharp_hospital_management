﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System
{
    class PublicClass
    {
        public static Panel pnlMenu, pnlContentOne,pnlContentTwo,pnlView, pnlForm;
        public static Form frmControl;
        public static Label lblTitle;

        public delegate Task refreshDatagrid(string query);
        public static refreshDatagrid refreshdata;
    }
}

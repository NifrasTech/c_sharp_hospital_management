﻿namespace Hospital_Management_System.Ward_Incharge
{
    partial class ucWard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlView = new System.Windows.Forms.Panel();
            this.pnlBed = new System.Windows.Forms.FlowLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.rbAll = new System.Windows.Forms.RadioButton();
            this.rbOccupied = new System.Windows.Forms.RadioButton();
            this.rbAvailable = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.btnWard = new System.Windows.Forms.Button();
            this.cmbWard = new System.Windows.Forms.ComboBox();
            this.pnlForm = new System.Windows.Forms.Panel();
            this.pnlView.SuspendLayout();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlView
            // 
            this.pnlView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlView.Controls.Add(this.pnlBed);
            this.pnlView.Controls.Add(this.panel1);
            this.pnlView.Controls.Add(this.pnlTop);
            this.pnlView.Location = new System.Drawing.Point(0, 0);
            this.pnlView.Name = "pnlView";
            this.pnlView.Size = new System.Drawing.Size(1000, 500);
            this.pnlView.TabIndex = 0;
            // 
            // pnlBed
            // 
            this.pnlBed.AutoScroll = true;
            this.pnlBed.BackColor = System.Drawing.Color.White;
            this.pnlBed.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlBed.Location = new System.Drawing.Point(0, 102);
            this.pnlBed.Name = "pnlBed";
            this.pnlBed.Padding = new System.Windows.Forms.Padding(35, 5, 0, 0);
            this.pnlBed.Size = new System.Drawing.Size(1000, 398);
            this.pnlBed.TabIndex = 4;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 61);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1000, 41);
            this.panel1.TabIndex = 5;
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.White;
            this.pnlTop.Controls.Add(this.rbAll);
            this.pnlTop.Controls.Add(this.rbOccupied);
            this.pnlTop.Controls.Add(this.rbAvailable);
            this.pnlTop.Controls.Add(this.button1);
            this.pnlTop.Controls.Add(this.btnWard);
            this.pnlTop.Controls.Add(this.cmbWard);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1000, 61);
            this.pnlTop.TabIndex = 3;
            // 
            // rbAll
            // 
            this.rbAll.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.rbAll.AutoSize = true;
            this.rbAll.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbAll.ForeColor = System.Drawing.Color.Black;
            this.rbAll.Location = new System.Drawing.Point(753, 20);
            this.rbAll.Name = "rbAll";
            this.rbAll.Size = new System.Drawing.Size(46, 26);
            this.rbAll.TabIndex = 109;
            this.rbAll.Text = "All";
            this.rbAll.UseVisualStyleBackColor = true;
            this.rbAll.Click += new System.EventHandler(this.rbAll_Click);
            // 
            // rbOccupied
            // 
            this.rbOccupied.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.rbOccupied.AutoSize = true;
            this.rbOccupied.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbOccupied.ForeColor = System.Drawing.Color.Black;
            this.rbOccupied.Location = new System.Drawing.Point(894, 20);
            this.rbOccupied.Name = "rbOccupied";
            this.rbOccupied.Size = new System.Drawing.Size(96, 26);
            this.rbOccupied.TabIndex = 110;
            this.rbOccupied.Text = "Occupied";
            this.rbOccupied.UseVisualStyleBackColor = true;
            this.rbOccupied.Click += new System.EventHandler(this.rbOccupied_Click);
            // 
            // rbAvailable
            // 
            this.rbAvailable.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.rbAvailable.AutoSize = true;
            this.rbAvailable.Checked = true;
            this.rbAvailable.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbAvailable.ForeColor = System.Drawing.Color.Black;
            this.rbAvailable.Location = new System.Drawing.Point(800, 20);
            this.rbAvailable.Name = "rbAvailable";
            this.rbAvailable.Size = new System.Drawing.Size(94, 26);
            this.rbAvailable.TabIndex = 110;
            this.rbAvailable.TabStop = true;
            this.rbAvailable.Text = "Available";
            this.rbAvailable.UseVisualStyleBackColor = true;
            this.rbAvailable.Click += new System.EventHandler(this.rbAvailable_Click);
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(64)))), ((int)(((byte)(181)))));
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(64)))), ((int)(((byte)(181)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Calibri", 12F);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(348, 19);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(131, 29);
            this.button1.TabIndex = 108;
            this.button1.Text = "Manage Room";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnWard
            // 
            this.btnWard.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnWard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnWard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnWard.FlatAppearance.BorderSize = 0;
            this.btnWard.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(64)))), ((int)(((byte)(181)))));
            this.btnWard.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(64)))), ((int)(((byte)(181)))));
            this.btnWard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWard.Font = new System.Drawing.Font("Calibri", 12F);
            this.btnWard.ForeColor = System.Drawing.Color.White;
            this.btnWard.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnWard.Location = new System.Drawing.Point(214, 19);
            this.btnWard.Name = "btnWard";
            this.btnWard.Size = new System.Drawing.Size(131, 29);
            this.btnWard.TabIndex = 108;
            this.btnWard.Text = "Manage Ward";
            this.btnWard.UseVisualStyleBackColor = false;
            this.btnWard.Click += new System.EventHandler(this.btnWard_Click);
            // 
            // cmbWard
            // 
            this.cmbWard.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.cmbWard.DropDownHeight = 300;
            this.cmbWard.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbWard.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbWard.FormattingEnabled = true;
            this.cmbWard.IntegralHeight = false;
            this.cmbWard.ItemHeight = 21;
            this.cmbWard.Location = new System.Drawing.Point(13, 19);
            this.cmbWard.Name = "cmbWard";
            this.cmbWard.Size = new System.Drawing.Size(196, 29);
            this.cmbWard.TabIndex = 107;
            this.cmbWard.SelectedIndexChanged += new System.EventHandler(this.cmbWard_SelectedIndexChanged);
            // 
            // pnlForm
            // 
            this.pnlForm.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlForm.BackColor = System.Drawing.Color.White;
            this.pnlForm.Location = new System.Drawing.Point(0, 0);
            this.pnlForm.Name = "pnlForm";
            this.pnlForm.Size = new System.Drawing.Size(1000, 500);
            this.pnlForm.TabIndex = 0;
            // 
            // ucWard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlView);
            this.Controls.Add(this.pnlForm);
            this.Name = "ucWard";
            this.Size = new System.Drawing.Size(1000, 500);
            this.Load += new System.EventHandler(this.ucWard_Load);
            this.pnlView.ResumeLayout(false);
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlView;
        private System.Windows.Forms.FlowLayoutPanel pnlBed;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.RadioButton rbAll;
        private System.Windows.Forms.RadioButton rbOccupied;
        private System.Windows.Forms.RadioButton rbAvailable;
        private System.Windows.Forms.Button btnWard;
        private System.Windows.Forms.ComboBox cmbWard;
        private System.Windows.Forms.Panel pnlForm;
        private System.Windows.Forms.Button button1;
    }
}

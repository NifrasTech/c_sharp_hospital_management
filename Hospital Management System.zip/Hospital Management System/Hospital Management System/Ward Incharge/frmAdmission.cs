﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Ward_Incharge
{
    public partial class frmAdmission : Form
    {
        public frmAdmission(ucBed bed,PictureBox picBed)
        {
            InitializeComponent();
            this.bed = bed;
            this.picBed = picBed;
        }

        ucBed bed;
        PictureBox picBed;

        DataTable dTable = new DataTable();
        Database database = new Database();
        string patientID, admissionno;
        public string bedid, bedno;

        // Generate Admission No
        void generateAdmissionNo()
        {
            try
            {
                dTable = new Database().viewData("select max(id) from ipdadmission");
                int maxid;
                if (dTable.Rows[0][0].ToString() == "") maxid = 0;
                else maxid = int.Parse(dTable.Rows[0][0].ToString());
                string id = String.Format("{0:D4}", maxid + 1);
                admissionno = "ADM/" + id;
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        async void getRoomCharge()
        {
            dTable = await new Database().GetData("select roomcharge from bed inner join room on room.roomno=bed.roomno where bedid="+bedid);
            txtCharge.Text = "Rs. " + dTable.Rows[0][0].ToString();
        }

        // close Form
        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        // Admit Patient
        private void btnAdmit_Click(object sender, EventArgs e)
        {
            string insertquery = @"INSERT INTO `ipdadmission`(`admissionno`, `patientid`, `bedid`, `admissiondate`, `status`) 
            VALUES ('"+admissionno+"',"+patientID+","+bedid+",'"+dtpDate.Text+"','Inward')";

            string updateBed = "UPDATE `bed` SET `status`='Occupied' WHERE bed.bedid ="+bedid;

            database.ExecuteQry(insertquery);
            database.ExecuteQry(updateBed);

            picBed.Image = Properties.Resources.bedOccupied;
            bed.BackColor = Color.Crimson;

            this.Close();
        }

        bool checkPatientAdmit()
        {
            dTable = database.viewData("select admissionno from ipdadmission where patientid="+patientID+" and status='Inward'");
            if (dTable.Rows.Count == 0) return true;
            else return false;
        }

        // Get Patient ID
        private void dgvPatient_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvPatient.SelectedRows.Count != 0)
            {
                btnAdmit.Enabled = true;
                patientID = dgvPatient.SelectedRows[0].Cells[0].Value.ToString();
                txtPatient.Text = dgvPatient.SelectedRows[0].Cells[1].Value.ToString();
                if (checkPatientAdmit()) btnAdmit.Enabled = true;
                else btnAdmit.Enabled = false;
            }
            else btnAdmit.Enabled = false;
        }

        // Form Shown
        private async void frmAdmission_Shown(object sender, EventArgs e)
        {
            dgvPatient.DataSource = await new Database().GetData("select patid,fullname,nic,gender from patient");
            txtBeds.Text = bedno;
            generateAdmissionNo();
            getRoomCharge();
            lblAdmission.Text = admissionno;
        }

        // Patient Search
        private async void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string search = txtSearch.Text;
            dgvPatient.DataSource = await new Database().GetData(@"select patid,fullname,nic,gender from patient where patid like 
            ('%"+search+ "%') or fullname like ('%" + search + "%') or nic like ('%" + search + "%')");
        }
    }
}

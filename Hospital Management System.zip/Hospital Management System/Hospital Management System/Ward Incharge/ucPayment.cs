﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Ward_Incharge
{
    public partial class ucPayment : UserControl
    {
        public ucPayment()
        {
            InitializeComponent();
            loadData(viewQuery);
        }

        Database database = new Database();

        string viewQuery= @"SELECT `billno`, ipdbill.`admissionno`, ipdadmission.admissiondate,`roomcharge`, patient.fullname, `medcharge`, `trtcharge`, `total`, `billdate` FROM `ipdbill` 
        INNER JOIN ipdadmission on ipdadmission.admissionno=ipdbill.admissionno INNER JOIN patient ON patient.patid = ipdadmission.patientid WHERE 1";

        string reportQuery, admissionno;
        async void loadData(string query)
        {
            try
            {
                dgvBill.DataSource = await database.GetData(viewQuery);
                reportQuery = query;
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            new frmWardIncomeReport(reportQuery).ShowDialog();
        }

        private void btnDetails_Click(object sender, EventArgs e)
        {
            new frmWardBill(admissionno).ShowDialog();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {

        }

        private void ucPayment_Load(object sender, EventArgs e)
        {

        }

        private void dgvBill_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvBill.SelectedRows.Count != 0)
            {
                btnDetails.Enabled = true;
                admissionno = dgvBill.SelectedRows[0].Cells[1].Value.ToString();
            }
            else btnDetails.Enabled = false;
        }
    }
}

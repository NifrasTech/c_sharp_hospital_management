﻿namespace Hospital_Management_System.Ward_Incharge
{
    partial class ucInchargeHome
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucInchargeHome));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblBed = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblWard = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblAvailable = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblOccupied = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblPatient = new System.Windows.Forms.Label();
            this.lblMessage = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(513, 171);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(473, 483);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 91;
            this.pictureBox1.TabStop = false;
            // 
            // lblBed
            // 
            this.lblBed.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblBed.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblBed.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblBed.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBed.ForeColor = System.Drawing.Color.White;
            this.lblBed.Image = ((System.Drawing.Image)(resources.GetObject("lblBed.Image")));
            this.lblBed.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblBed.Location = new System.Drawing.Point(32, 258);
            this.lblBed.Name = "lblBed";
            this.lblBed.Padding = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.lblBed.Size = new System.Drawing.Size(149, 60);
            this.lblBed.TabIndex = 92;
            this.lblBed.Text = "0";
            this.lblBed.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.label5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label5.Location = new System.Drawing.Point(33, 321);
            this.label5.Name = "label5";
            this.label5.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.label5.Size = new System.Drawing.Size(148, 23);
            this.label5.TabIndex = 93;
            this.label5.Text = "No of Beds";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1.Location = new System.Drawing.Point(33, 214);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.label1.Size = new System.Drawing.Size(148, 23);
            this.label1.TabIndex = 93;
            this.label1.Text = "No of Ward";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWard
            // 
            this.lblWard.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblWard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblWard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblWard.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWard.ForeColor = System.Drawing.Color.White;
            this.lblWard.Image = ((System.Drawing.Image)(resources.GetObject("lblWard.Image")));
            this.lblWard.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblWard.Location = new System.Drawing.Point(32, 153);
            this.lblWard.Name = "lblWard";
            this.lblWard.Padding = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.lblWard.Size = new System.Drawing.Size(149, 60);
            this.lblWard.TabIndex = 92;
            this.lblWard.Text = "0";
            this.lblWard.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.label3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label3.Location = new System.Drawing.Point(33, 428);
            this.label3.Name = "label3";
            this.label3.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.label3.Size = new System.Drawing.Size(148, 23);
            this.label3.TabIndex = 93;
            this.label3.Text = "Available Bed";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblAvailable
            // 
            this.lblAvailable.BackColor = System.Drawing.Color.SeaGreen;
            this.lblAvailable.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblAvailable.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblAvailable.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAvailable.ForeColor = System.Drawing.Color.White;
            this.lblAvailable.Image = ((System.Drawing.Image)(resources.GetObject("lblAvailable.Image")));
            this.lblAvailable.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblAvailable.Location = new System.Drawing.Point(32, 364);
            this.lblAvailable.Name = "lblAvailable";
            this.lblAvailable.Padding = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.lblAvailable.Size = new System.Drawing.Size(149, 60);
            this.lblAvailable.TabIndex = 92;
            this.lblAvailable.Text = "0";
            this.lblAvailable.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.label6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label6.Location = new System.Drawing.Point(33, 539);
            this.label6.Name = "label6";
            this.label6.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.label6.Size = new System.Drawing.Size(148, 23);
            this.label6.TabIndex = 93;
            this.label6.Text = "Occupied";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOccupied
            // 
            this.lblOccupied.BackColor = System.Drawing.Color.Crimson;
            this.lblOccupied.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblOccupied.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblOccupied.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOccupied.ForeColor = System.Drawing.Color.White;
            this.lblOccupied.Image = ((System.Drawing.Image)(resources.GetObject("lblOccupied.Image")));
            this.lblOccupied.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblOccupied.Location = new System.Drawing.Point(32, 475);
            this.lblOccupied.Name = "lblOccupied";
            this.lblOccupied.Padding = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.lblOccupied.Size = new System.Drawing.Size(149, 60);
            this.lblOccupied.TabIndex = 92;
            this.lblOccupied.Text = "0";
            this.lblOccupied.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.label8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label8.Location = new System.Drawing.Point(33, 113);
            this.label8.Name = "label8";
            this.label8.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.label8.Size = new System.Drawing.Size(148, 23);
            this.label8.TabIndex = 93;
            this.label8.Text = "Admitted Patient";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPatient
            // 
            this.lblPatient.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblPatient.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblPatient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblPatient.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPatient.ForeColor = System.Drawing.Color.White;
            this.lblPatient.Image = ((System.Drawing.Image)(resources.GetObject("lblPatient.Image")));
            this.lblPatient.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblPatient.Location = new System.Drawing.Point(32, 52);
            this.lblPatient.Name = "lblPatient";
            this.lblPatient.Padding = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.lblPatient.Size = new System.Drawing.Size(149, 60);
            this.lblPatient.TabIndex = 92;
            this.lblPatient.Text = "0";
            this.lblPatient.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblMessage
            // 
            this.lblMessage.BackColor = System.Drawing.Color.Gainsboro;
            this.lblMessage.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblMessage.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.ForeColor = System.Drawing.Color.Crimson;
            this.lblMessage.Location = new System.Drawing.Point(0, 0);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(1020, 40);
            this.lblMessage.TabIndex = 101;
            this.lblMessage.Text = "Welcome";
            this.lblMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ucInchargeHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.lblOccupied);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblAvailable);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblWard);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblPatient);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lblBed);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pictureBox1);
            this.Name = "ucInchargeHome";
            this.Size = new System.Drawing.Size(1020, 650);
            this.Load += new System.EventHandler(this.ucInchargeHome_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblBed;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblWard;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblAvailable;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblOccupied;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblPatient;
        private System.Windows.Forms.Label lblMessage;
    }
}

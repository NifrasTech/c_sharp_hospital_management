﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Ward_Incharge
{
    public partial class frmWardpatientReport : Form
    {
        string reportquery;
        public frmWardpatientReport(string query)
        {
            InitializeComponent();
            dsWardPatientBindingSource.DataSource = new Database().viewData(query);
            reportquery = query;
        }

        private void frmWardpatientReport_Load(object sender, EventArgs e)
        {
            this.reportViewer1.RefreshReport();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            try
            {
                dsWardPatientBindingSource.DataSource = new Database().viewData(reportquery + " and admissiondate between '" + dtpStart.Text + "' AND '" + dtpEnd.Text + "'");
                this.reportViewer1.RefreshReport();
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void picRefresh_Click(object sender, EventArgs e)
        {
            try
            {
                dsWardPatientBindingSource.DataSource = new Database().viewData(reportquery);
                this.reportViewer1.RefreshReport();
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }
    }
}

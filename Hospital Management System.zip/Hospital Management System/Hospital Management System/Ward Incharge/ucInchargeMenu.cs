﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Ward_Incharge
{
    public partial class ucInchargeMenu : UserControl
    {
        public ucInchargeMenu()
        {
            InitializeComponent();
        }

        Animation animation = new Animation();

        void activeButton(Button button)
        {
            animation.activeButton(button, lblActive);
        }

        private void ucInchargeMenu_Load(object sender, EventArgs e)
        {
            activeButton(btnHome);
            ucInchargeHome incharge = new ucInchargeHome();
            animation.loadContent(incharge, "Dashboard");
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            activeButton(btnHome);
            ucInchargeHome incharge = new ucInchargeHome();
            animation.loadContent(incharge, "Dashboard");
        }

        private void btnWard_Click(object sender, EventArgs e)
        {
            activeButton(btnWard);
            ucWard ward = new ucWard();
            animation.loadContent(ward,"Ward Management");
        }

        private void btnPatient_Click(object sender, EventArgs e)
        {
            activeButton(btnPatient);
            ucWardpatient patient = new ucWardpatient();
            animation.loadContent(patient, "Ward Patient");
        }

        private void btnPayment_Click(object sender, EventArgs e)
        {
            activeButton(btnPayment);
            ucPayment payment = new ucPayment();
            animation.loadContent(payment, "Hospital Bill Details");
        }

        private void btnSetting_Click(object sender, EventArgs e)
        {
            activeButton(btnSetting);
            ucChangePassword changepassword = new ucChangePassword();
            animation.loadContent(changepassword, "Change Password");
        }
    }
}

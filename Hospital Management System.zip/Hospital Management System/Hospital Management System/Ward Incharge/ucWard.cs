﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Ward_Incharge
{
    public partial class ucWard : UserControl
    {
        public ucWard()
        {
            InitializeComponent();
        }

        DataTable dTable = new DataTable();
        Animation animation = new Animation();
        int wardid;
        string bedViewQuery = "SELECT `bedid`,`bedno`, `status` FROM `bed` INNER JOIN room on bed.roomno=room.roomno INNER join ward on room.wardid=ward.wardid WHERE ward.wardid=";

        // Load Ward
        async void loadWard()
        {
            try
            {
                dTable = await new Database().GetData("select wardid,concat(ward,' - ',wardno) as ward from ward");

                if (dTable.Rows.Count != 0)
                {
                    cmbWard.DisplayMember = "ward";
                    cmbWard.ValueMember = "wardid";
                    cmbWard.DataSource = dTable;
                    cmbWard.SelectedIndex = 0;
                }
                else
                {
                    cmbWard.Items.Add("Ward is Empty");
                    cmbWard.SelectedIndex = 0;
                    cmbWard.Enabled = false;
                }
            }
            catch (Exception exc)
            {
                animation.notification(Color.Crimson, "Error", exc.Message);
            }
        }

        // Form Load
        private async void ucWard_Load(object sender, EventArgs e)
        {
            PublicClass.pnlForm = pnlForm;
            PublicClass.pnlView = pnlView;
            await Task.Delay(1000);
            loadWard();    
        }

        // Load Beds
        async void loadBeds()
        {
            try
            {
                string currentQuery="";
                if (cmbWard.Text != "Ward is Empty")
                {
                    wardid = int.Parse(cmbWard.SelectedValue.ToString()); // Get ward ID

                    if (rbAll.Checked == true) currentQuery = bedViewQuery + wardid;
                    else if (rbAvailable.Checked == true) currentQuery= bedViewQuery+wardid+" and status='Available'";
                    if (rbOccupied.Checked == true) currentQuery=bedViewQuery+wardid+" and status='Occupied'";
                    dTable = await new Database().GetData(currentQuery);
                    pnlBed.Controls.Clear();
                    int total = dTable.Rows.Count;
                    if (total != 0)
                    {
                        for (int i = 0; i < total; i++)
                        {
                            if (dTable.Rows[i]["status"].ToString() == "Available")
                            {
                                ucBed bed = new ucBed(Color.SeaGreen, Properties.Resources.bedAvailable, dTable.Rows[i][1].ToString(), dTable.Rows[i][0].ToString());
                                bed.Cursor = Cursors.Hand;
                                pnlBed.Controls.Add(bed);
                            }
                            else if(dTable.Rows[i]["status"].ToString() == "Occupied")
                            {
                                ucBed bed = new ucBed(Color.Crimson, Properties.Resources.bedOccupied, dTable.Rows[i][1].ToString(), dTable.Rows[i][0].ToString());
                                bed.Cursor = Cursors.Hand;
                                pnlBed.Controls.Add(bed);
                            }
                        }
                    }
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        // Combo Box Selection Changed
        private void cmbWard_SelectedIndexChanged(object sender, EventArgs e)
        {
            loadBeds();
        }

        // Manage Ward form
        private void btnWard_Click(object sender, EventArgs e)
        {
            frmWard ward = new frmWard();
            PublicClass.frmControl = ward;
            ward.loadCombo = loadWard;
            new Animation().changeView();
        }

        // Manage room form
        private void button1_Click(object sender, EventArgs e)
        {
            PublicClass.frmControl = new frmRoom();
            new Animation().changeView();
        }

        private void rbAvailable_Click(object sender, EventArgs e)
        {
            loadBeds();
        }

        private void rbAll_Click(object sender, EventArgs e)
        {
            loadBeds();
        }

        private void rbOccupied_Click(object sender, EventArgs e)
        {
            loadBeds();
        }
    }
}

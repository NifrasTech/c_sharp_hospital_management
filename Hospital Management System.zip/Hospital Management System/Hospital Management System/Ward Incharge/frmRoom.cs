﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Ward_Incharge
{
    public partial class frmRoom : Form
    {
        public frmRoom()
        {
            InitializeComponent();
        }

        DataTable dTable = new DataTable();
        Database database = new Database();
        Validation validation = new Validation();

        string wardid, charge, nobeds, description, roomid, roomno, bedid, status;
        string bedViewQuery = "SELECT `bedid`, `bedno`, `status` FROM `bed` WHERE roomno=";
        string roomViewQuery = "SELECT `roomid`, `wardid`, `roomno`, `roomcharge`, `description` FROM `room` WHERE wardid=";

        void insertbed()
        {
            try
            {
                int totalBed = int.Parse(txtBeds.Text);

                for (int i = 0; i <totalBed; i++)
                {
                    string id = String.Format("{0:D2}", i + 1);
                    database.ExecuteQry("INSERT INTO `bed`(`roomno`, `bedno`, `status`) VALUES ('"+roomno+"','"+roomno+"/B-"+id+"','Available')");
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        // Generate room no
        void generateRoomNo()
        {
            try
            {
                dTable = database.viewData("select max(roomid) from room");
                int maxuserid;
                if (dTable.Rows[0][0].ToString() == "") maxuserid = 0;
                else maxuserid = int.Parse(dTable.Rows[0][0].ToString());
                string id = String.Format("{0:D2}", maxuserid + 1);
                roomno = "RM/" + id;
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        // Insert Room Details
        void insertRoom()
        {
            try
            {
                generateRoomNo();
                database.ExecuteQry("INSERT INTO `room`(`wardid`, `roomno`, `roomcharge`, `description`) VALUES ("+wardid+",'"+roomno+"',"+charge+",'"+description+"')");
                insertbed();
                loadRoom();
                validation.resetControls(gbRoom);
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        // Update Room Details
        void updateRoom()
        {
            try
            {
                database.ExecuteQry("UPDATE `room` SET `roomcharge`="+charge+",`description`='"+description+"' WHERE roomid="+roomid);
                loadRoom();
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        // Button Save Click
        private void btnSave_Click(object sender, EventArgs e)
        {
            nobeds = txtBeds.Text;
            description = txtDescription.Text;
            charge = txtCharge.Text;
            if (validation.textBoxEmpty(gbRoom))
            {
                if (btnSave.Text == "Save") insertRoom();
                else updateRoom();
            }
        }

        // Button Edit Click
        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dgvRoom.SelectedRows.Count != 0)
            {
                txtBeds.Enabled = false;
                btnSave.Text = "Update";

                txtCharge.Text = dgvRoom.SelectedRows[0].Cells[3].Value.ToString();
                txtDescription.Text = dgvRoom.SelectedRows[0].Cells[4].Value.ToString();
            }

        }

        //Room Remove
        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (dgvRoom.SelectedRows.Count != 0)
            {
                if (dgvBed.Rows.Count != 0) MessageBox.Show("Make sure that you dont have any beds available in this room");
                else database.ExecuteQry("delete from room where roomid="+roomid);
                loadRoom();
            }
        }

        // Reset Controls
        private void btnCancel_Click(object sender, EventArgs e)
        {
            validation.resetControls(gbRoom);
            btnSave.Text = "Save";
            txtBeds.Enabled = true;
        }

        // Load Ward
        async void loadWard()
        {
            try
            {
                dTable = await new Database().GetData("select wardid,concat(ward,' - ',wardno) as ward from ward");

                if (dTable.Rows.Count != 0)
                {
                    cmbWard.DisplayMember = "ward";
                    cmbWard.ValueMember = "wardid";
                    cmbWard.DataSource = dTable;
                    cmbWard.SelectedIndex = 0;
                }
                else
                {
                    cmbWard.Items.Add("Ward is Empty");
                    cmbWard.SelectedIndex = 0;
                    cmbWard.Enabled = false;
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        // Load Room Details
        async void loadRoom()
        {
            try
            {
                dgvRoom.DataSource = await database.GetData("SELECT `roomid`, `wardid`, `roomno`, `roomcharge`, `description` FROM `room` WHERE wardid=" + wardid);
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        // Load Beds
        async void loadBed()
        {
            try
            {
                dgvBed.DataSource = await database.GetData("SELECT `bedid`, `bedno`, `status` FROM `bed` WHERE roomno='"+roomno+"'");
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        // Back to Previuos
        private void button6_Click(object sender, EventArgs e)
        {
            new Animation().changeView();
        }

        // Room Data Grid Selected index changed
        private void dgvRoom_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvRoom.SelectedRows.Count != 0)
            {
                roomid = dgvRoom.SelectedRows[0].Cells[0].Value.ToString();
                roomno = dgvRoom.SelectedRows[0].Cells[2].Value.ToString();
                loadBed();
            }
        }

        private void frmRoom_Load(object sender, EventArgs e)
        {
            loadWard();
        }

        private void cmbWard_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbWard.Text != "Ward is Empty")
            {
                wardid = cmbWard.SelectedValue.ToString();
                loadRoom();
            }
        }

        private void btnRemoveBed_Click(object sender, EventArgs e)
        {
            if (dgvBed.SelectedRows.Count != 0)
            {
                bedid = dgvBed.SelectedRows[0].Cells[0].Value.ToString();
                status = dgvBed.SelectedRows[0].Cells[2].Value.ToString();
                if (status == "Available") database.ExecuteQry("delete from bed where bedid="+bedid);
                loadBed();
            }
        }
    }
}

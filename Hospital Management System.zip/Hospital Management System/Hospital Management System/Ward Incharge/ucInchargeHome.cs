﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Ward_Incharge
{
    public partial class ucInchargeHome : UserControl
    {
        public ucInchargeHome()
        {
            InitializeComponent();
        }

        Animation animation = new Animation();
        Database database = new Database();

        private async void ucInchargeHome_Load(object sender, EventArgs e)
        {
            lblMessage.Text = "Welcome to the Acesco Hospital Management System, " + User.nameofuser + "!";
            await Task.Delay(1500);
            Task<int> loadTask = loadAsync();
            int result = await loadTask;
        }

        async Task<int> loadAsync()
        {
            animation.textAnimation(lblWard, database.getOneValue("select COUNT(wardid) from ward"));
            animation.textAnimation(lblBed, database.getOneValue("select COUNT(bedid) FROM bed"));
            animation.textAnimation(lblOccupied, database.getOneValue("select COUNT(bedid) FROM bed where status='Occupied'"));
            animation.textAnimation(lblPatient, database.getOneValue("SELECT COUNT(admissionno) FROM ipdadmission where status='Inward'"));
            animation.textAnimation(lblAvailable, database.getOneValue("select COUNT(bedid) FROM bed where status='Available'"));

            return 1;
        }
    }
}

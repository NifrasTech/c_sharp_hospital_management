﻿namespace Hospital_Management_System.Ward_Incharge
{
    partial class frmDischarge
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDischarge));
            this.lblAdmission = new System.Windows.Forms.Label();
            this.txtDay = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnDischarge = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.gbDischarge = new System.Windows.Forms.GroupBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblDiscgarge = new System.Windows.Forms.Label();
            this.lblTreatment = new System.Windows.Forms.Label();
            this.lblMedicine = new System.Windows.Forms.Label();
            this.lblAdmitDate = new System.Windows.Forms.Label();
            this.lblRoomCharge = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnBack = new System.Windows.Forms.Button();
            this.gbDischarge.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblAdmission
            // 
            this.lblAdmission.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblAdmission.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdmission.Location = new System.Drawing.Point(161, 31);
            this.lblAdmission.Name = "lblAdmission";
            this.lblAdmission.Size = new System.Drawing.Size(157, 30);
            this.lblAdmission.TabIndex = 107;
            this.lblAdmission.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtDay
            // 
            this.txtDay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDay.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDay.Location = new System.Drawing.Point(161, 124);
            this.txtDay.Name = "txtDay";
            this.txtDay.Size = new System.Drawing.Size(157, 29);
            this.txtDay.TabIndex = 105;
            this.txtDay.Text = "1";
            this.txtDay.TextChanged += new System.EventHandler(this.txtDay_TextChanged);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(19, 174);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(128, 23);
            this.label6.TabIndex = 107;
            this.label6.Text = "Room Charge :";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnDischarge
            // 
            this.btnDischarge.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnDischarge.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDischarge.FlatAppearance.BorderSize = 0;
            this.btnDischarge.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.HotTrack;
            this.btnDischarge.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDischarge.Font = new System.Drawing.Font("Calibri", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDischarge.ForeColor = System.Drawing.Color.White;
            this.btnDischarge.Location = new System.Drawing.Point(159, 404);
            this.btnDischarge.Name = "btnDischarge";
            this.btnDischarge.Size = new System.Drawing.Size(157, 30);
            this.btnDischarge.TabIndex = 88;
            this.btnDischarge.Text = "Discharge";
            this.btnDischarge.UseVisualStyleBackColor = false;
            this.btnDischarge.Click += new System.EventHandler(this.btnDischarge_Click);
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(19, 35);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 23);
            this.label4.TabIndex = 107;
            this.label4.Text = "Admission No :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // gbDischarge
            // 
            this.gbDischarge.Controls.Add(this.lblTotal);
            this.gbDischarge.Controls.Add(this.lblDiscgarge);
            this.gbDischarge.Controls.Add(this.lblTreatment);
            this.gbDischarge.Controls.Add(this.lblMedicine);
            this.gbDischarge.Controls.Add(this.txtDay);
            this.gbDischarge.Controls.Add(this.lblAdmitDate);
            this.gbDischarge.Controls.Add(this.lblRoomCharge);
            this.gbDischarge.Controls.Add(this.lblAdmission);
            this.gbDischarge.Controls.Add(this.btnDischarge);
            this.gbDischarge.Controls.Add(this.label8);
            this.gbDischarge.Controls.Add(this.label1);
            this.gbDischarge.Controls.Add(this.label7);
            this.gbDischarge.Controls.Add(this.label10);
            this.gbDischarge.Controls.Add(this.label6);
            this.gbDischarge.Controls.Add(this.label13);
            this.gbDischarge.Controls.Add(this.label4);
            this.gbDischarge.Controls.Add(this.label11);
            this.gbDischarge.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gbDischarge.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbDischarge.Location = new System.Drawing.Point(19, 45);
            this.gbDischarge.Name = "gbDischarge";
            this.gbDischarge.Size = new System.Drawing.Size(341, 441);
            this.gbDischarge.TabIndex = 110;
            this.gbDischarge.TabStop = false;
            this.gbDischarge.Text = "Discharge";
            // 
            // lblTotal
            // 
            this.lblTotal.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblTotal.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(161, 350);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(157, 30);
            this.lblTotal.TabIndex = 107;
            this.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDiscgarge
            // 
            this.lblDiscgarge.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblDiscgarge.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDiscgarge.Location = new System.Drawing.Point(161, 305);
            this.lblDiscgarge.Name = "lblDiscgarge";
            this.lblDiscgarge.Size = new System.Drawing.Size(157, 30);
            this.lblDiscgarge.TabIndex = 107;
            this.lblDiscgarge.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTreatment
            // 
            this.lblTreatment.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblTreatment.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTreatment.Location = new System.Drawing.Point(161, 260);
            this.lblTreatment.Name = "lblTreatment";
            this.lblTreatment.Size = new System.Drawing.Size(157, 30);
            this.lblTreatment.TabIndex = 107;
            this.lblTreatment.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMedicine
            // 
            this.lblMedicine.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblMedicine.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMedicine.Location = new System.Drawing.Point(161, 215);
            this.lblMedicine.Name = "lblMedicine";
            this.lblMedicine.Size = new System.Drawing.Size(157, 30);
            this.lblMedicine.TabIndex = 107;
            this.lblMedicine.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblAdmitDate
            // 
            this.lblAdmitDate.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblAdmitDate.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdmitDate.Location = new System.Drawing.Point(161, 80);
            this.lblAdmitDate.Name = "lblAdmitDate";
            this.lblAdmitDate.Size = new System.Drawing.Size(157, 30);
            this.lblAdmitDate.TabIndex = 107;
            this.lblAdmitDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblRoomCharge
            // 
            this.lblRoomCharge.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblRoomCharge.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRoomCharge.Location = new System.Drawing.Point(161, 170);
            this.lblRoomCharge.Name = "lblRoomCharge";
            this.lblRoomCharge.Size = new System.Drawing.Size(157, 30);
            this.lblRoomCharge.TabIndex = 107;
            this.lblRoomCharge.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(19, 264);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(128, 23);
            this.label8.TabIndex = 107;
            this.label8.Text = "Treatment Fee :";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(19, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 23);
            this.label1.TabIndex = 107;
            this.label1.Text = "Admitted Date :";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(19, 219);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(128, 23);
            this.label7.TabIndex = 107;
            this.label7.Text = "Medicine Fee :";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(19, 128);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(128, 23);
            this.label10.TabIndex = 107;
            this.label10.Text = "No of Day :";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(2, 354);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(141, 23);
            this.label13.TabIndex = 107;
            this.label13.Text = "Total :";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(6, 309);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(141, 23);
            this.label11.TabIndex = 107;
            this.label11.Text = "Discharge Date :";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.btnBack);
            this.panel1.Controls.Add(this.gbDischarge);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(5, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(380, 489);
            this.panel1.TabIndex = 113;
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.Transparent;
            this.btnBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Font = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnBack.Image = ((System.Drawing.Image)(resources.GetObject("btnBack.Image")));
            this.btnBack.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBack.Location = new System.Drawing.Point(3, 2);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(88, 37);
            this.btnBack.TabIndex = 111;
            this.btnBack.Text = "Back";
            this.btnBack.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // frmDischarge
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HotTrack;
            this.ClientSize = new System.Drawing.Size(390, 499);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmDischarge";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.Text = " ";
            this.Shown += new System.EventHandler(this.frmDischarge_Shown);
            this.gbDischarge.ResumeLayout(false);
            this.gbDischarge.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label lblAdmission;
        private System.Windows.Forms.TextBox txtDay;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.Button btnDischarge;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox gbDischarge;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblAdmitDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblMedicine;
        private System.Windows.Forms.Label lblRoomCharge;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblTreatment;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblDiscgarge;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label label13;
        public System.Windows.Forms.Button btnBack;
    }
}
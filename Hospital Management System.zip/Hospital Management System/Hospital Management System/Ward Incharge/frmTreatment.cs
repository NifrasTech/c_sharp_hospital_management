﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Front_Officer
{
    public partial class frmTreatment : Form
    {
        public frmTreatment(string admission, string patientname, bool discharge)
        {
            InitializeComponent();
            lblAdmission.Text = admission;
            lblPatient.Text = "Patient Name : " + patientname;
            loadTreatment();
            loadMedicine();

            if (discharge) { btnAddTreatment.Enabled = false; btnAddMedicine.Enabled = false; }

            validation.numbersOnly(txtTCharge);
            validation.numbersOnly(txtMcharge);
        }

        Database database = new Database();
        Validation validation = new Validation();
        Animation animation = new Animation();

        async void loadTreatment()
        {
            dgvTreatment.DataSource = await database.GetData("SELECT `treatment`, `fee` FROM `treatment` WHERE admissionno='" + lblAdmission.Text + "'");
        }

        async void loadMedicine()
        {
            dgvMedicine.DataSource = await database.GetData("SELECT `medcine`, `fee` FROM `medicine` WHERE admissionno='" + lblAdmission.Text + "'");
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            new Animation().changeView();
        }

        private void btnAddTreatment_Click(object sender, EventArgs e)
        {
            if (validation.textBoxEmpty(gbTreatment))
            {
                database.ExecuteQry("INSERT INTO `treatment`(`admissionno`, `treatment`, `fee`, `date`) VALUES ('"+lblAdmission.Text+"','"+txtTreatment.Text+"',"+txtTCharge.Text+",CURDATE())");
                loadTreatment();
                validation.resetControls(gbTreatment);
            }
            else animation.notification(Color.Crimson, "Failed", "Text Box Cannot be Empty");
        }

        private void btnAddMedicine_Click(object sender, EventArgs e)
        {
            if (validation.textBoxEmpty(gbMedicine))
            {
                database.ExecuteQry("INSERT INTO `medicine`(`admissionno`, `medcine`, `fee`, `date`) VALUES ('" + lblAdmission.Text + "','" + txtMedicine.Text + "'," + txtMcharge.Text + ",CURDATE())");
                loadMedicine();
                validation.resetControls(gbMedicine);
            }
            else animation.notification(Color.Crimson, "Failed", "Text Box Cannot be Empty");
        }
    }
}

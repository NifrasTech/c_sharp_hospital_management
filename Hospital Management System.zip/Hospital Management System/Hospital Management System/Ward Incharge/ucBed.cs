﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Ward_Incharge
{
    public partial class ucBed : UserControl
    {
        string bedid;
        public ucBed(Color color, Image image, string bedno, string bedid)
        {
            InitializeComponent();

            this.BackColor = color;
            picBed.Image = image;
            lblBedNo.Text = bedno;
            this.bedid = bedid;
        }

        Animation animation = new Animation();

        private void ucBed_Load(object sender, EventArgs e)
        {

        }

        private void picBed_Click(object sender, EventArgs e)
        {
            if (this.BackColor == Color.Crimson) animation.notification(Color.Crimson, "Bed Occupied", "The bed cannot be arranged...! occupied Already");
            else
            {
                frmAdmission admission = new frmAdmission(this,picBed);
                admission.bedid = bedid;
                admission.bedno = lblBedNo.Text;
                admission.ShowDialog();
            }
        }
    }
}

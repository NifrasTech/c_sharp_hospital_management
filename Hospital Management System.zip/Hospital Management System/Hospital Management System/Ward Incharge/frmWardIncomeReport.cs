﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Ward_Incharge
{
    public partial class frmWardIncomeReport : Form
    {
        string query;
        public frmWardIncomeReport(string query)
        {
            InitializeComponent();
            this.query = query;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private async void frmWardIncomeReport_Load(object sender, EventArgs e)
        {
            dsWardIncomeBindingSource.DataSource = await new Database().GetData(query);
            this.reportViewer1.RefreshReport();
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            try
            {
                dsWardIncomeBindingSource.DataSource = new Database().viewData(query + " and billdate between '" + dtpStart.Text + "' AND '" + dtpEnd.Text + "'");
                this.reportViewer1.RefreshReport();
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Ward_Incharge
{
    public partial class frmDischarge : Form
    {
        string bedid;
        double roomcharge, treatmentcharge, total, medicinecharge, totalroomcharge;
        public frmDischarge(string admissionno, string date, string bedid)
        {
            InitializeComponent();
            validation.numbersOnly(txtDay);
            lblAdmission.Text = admissionno;
            lblAdmitDate.Text = date;
            this.bedid = bedid;
            getCharge();
        }

        Validation validation = new Validation();
        DataTable dtable = new DataTable();
        Database database = new Database();
        Animation animation = new Animation();

        // Form Shown
        private void frmDischarge_Shown(object sender, EventArgs e)
        {
            getDischargeDate();
        }

        // Day Changed
        private void txtDay_TextChanged(object sender, EventArgs e)
        {
            getDischargeDate();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            new Animation().changeView();
        }

        void getDischargeDate()
        {
            if (txtDay.Text.Trim() == "") txtDay.Text = "1";

            DateTime date = Convert.ToDateTime(lblAdmitDate.Text);
            DateTime dischargedate = date.AddDays(double.Parse(txtDay.Text));
            lblDiscgarge.Text = dischargedate.ToShortDateString();
            calculation();
        }

        // Get Fee from Databse
        void getCharge()
        {
            try
            {
                dtable = database.viewData("select room.roomcharge from bed INNER JOIN room on bed.roomno = room.roomno where bedno='" + bedid + "'");
                roomcharge = double.Parse(dtable.Rows[0][0].ToString());
                dtable = database.viewData("SELECT ifnull(SUM(medicine.fee),0) from medicine where medicine.admissionno='" + lblAdmission.Text + "'");
                medicinecharge = double.Parse(dtable.Rows[0][0].ToString());
                dtable = database.viewData("SELECT ifnull(SUM(treatment.fee),0) from treatment where treatment.admissionno='" + lblAdmission.Text + "'");
                treatmentcharge = double.Parse(dtable.Rows[0][0].ToString());
            }
            catch (Exception exc)
            {
                animation.notification(Color.Crimson, "Error", exc.Message);
            }
        }

        // Calculate Fees
        void calculation()
        {
            totalroomcharge = double.Parse(txtDay.Text) * roomcharge;
            lblRoomCharge.Text = "Rs. " + totalroomcharge;
            lblMedicine.Text = "Rs." + medicinecharge;
            lblTreatment.Text = "Rs." + treatmentcharge;
            total = totalroomcharge + medicinecharge + treatmentcharge;
            lblTotal.Text = "Rs." + total;
        }

        // Discharge Patient
        private void btnDischarge_Click(object sender, EventArgs e)
        {
            try
            {
                string query = @"INSERT INTO `ipdbill`(`admissionno`, `roomcharge`, `medcharge`, `trtcharge`, `total`, `billdate`) 
                VALUES ('" + lblAdmission.Text + "'," + totalroomcharge + "," + medicinecharge + "," + treatmentcharge + "," + total + ",'" + lblDiscgarge.Text + "')";
                database.ExecuteQry(query);
                database.ExecuteQry("UPDATE `bed` SET `status`='Available' WHERE bed.bedid ='" + bedid+"'");
                database.ExecuteQry("UPDATE `ipdadmission` SET `status`='Discharged' WHERE admissionno='" + lblAdmission.Text + "'");
                animation.notification(Color.SeaGreen, "Success", "Patient Discharged");
                new frmWardBill(lblAdmission.Text).ShowDialog();
                new Animation().changeView();
            }
            catch (Exception exc)
            {
                animation.notification(Color.Crimson, "Error", exc.Message);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Ward_Incharge
{
    public delegate void comboDelegate();
    public partial class frmWard : Form
    {
        public frmWard()
        {
            InitializeComponent();
        }

        public comboDelegate loadCombo; // Load Combo Box Delegate

        string viewQuery = "SELECT `wardid`, `wardno`, `ward`, `description` FROM `ward` WHERE 1";
        string ward, description, wardid, wardno;

        Validation validation = new Validation();
        DataTable dTable = new DataTable();
        Database database = new Database();

        // Back to Home
        private void btnBack_Click(object sender, EventArgs e)
        {
            new Animation().changeView();
        }

        // Generate Ward No
        void generateWardNo()
        {
            try
            {
                dTable = database.viewData("select max(wardid) from ward");
                int maxuserid;
                if (dTable.Rows[0][0].ToString() == "") maxuserid = 0;
                else maxuserid = int.Parse(dTable.Rows[0][0].ToString());
                string id = String.Format("{0:D2}", maxuserid + 1);
                wardno = "WRD/" + id;
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        // Load Ward Details
        async void loadWard()
        {
            try
            {
                dgvWard.DataSource = await database.GetData(viewQuery);
                loadCombo();
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        // Insert Ward Data
        void insertData()
        {
            try
            {
                generateWardNo();
                database.ExecuteQry("INSERT INTO `ward`(`wardno`, `ward`, `description`) VALUES ('" + wardno + "','" + ward + "','" + description + "')");
                loadWard();
                validation.resetControls(gbWard);
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        // Insert Update Data
        void updateData()
        {
            try
            {
                database.ExecuteQry("UPDATE `ward` SET `ward`='" + ward + "',`description`='" + description + "' WHERE wardid=" + wardid);
                loadWard();
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        // Insert or Update Data
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtDescription.Text.Trim() == "") txtDescription.Text = "...";
            if (validation.textBoxEmpty(gbWard))
            {
                ward = txtWard.Text;
                description = txtDescription.Text;

                if (btnSave.Text == "Save") insertData();
                else updateData();
            }
        }

        // Select Ward ID
        private void dgvWard_SelectionChanged(object sender, EventArgs e)
        {
            if(dgvWard.SelectedRows.Count!=0) wardid = dgvWard.SelectedRows[0].Cells[0].Value.ToString();
        }

        private void frmWard_Load(object sender, EventArgs e)
        {
            loadWard();
        }

        // Edit Data
        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dgvWard.Rows.Count != 0)
            {
                txtWard.Text = dgvWard.SelectedRows[0].Cells[2].Value.ToString();
                txtDescription.Text = dgvWard.SelectedRows[0].Cells[3].Value.ToString();   
                btnSave.Text = "Update";
            }
        }

        //Remove Ward
        private void btnRemoveWard_Click(object sender, EventArgs e)
        {
            if (dgvWard.Rows.Count != 0)
            {
                database.ExecuteQry("delete from ward where wardid="+wardid);
                loadWard();
            }
        }

        // Cancel and Clear
        private void btnCancel_Click(object sender, EventArgs e)
        {
            validation.resetControls(gbWard);
            btnSave.Text = "Save";
        }
    }
}

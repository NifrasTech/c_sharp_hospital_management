﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Ward_Incharge
{
    public partial class ucWardpatient : UserControl
    {
        public ucWardpatient()
        {
            InitializeComponent();
            PublicClass.pnlView = pnlForm;
            PublicClass.pnlForm = pnlView;
        }
        Database database = new Database();
        Animation animation = new Animation();

        string admissionno, status, patientname, date, bedid;
        string viewQuery = @"SELECT `admissionno`, patient.fullname, ipdadmission.`status`, bed.bedno, CONCAT(TIMESTAMPDIFF(YEAR, patient.dob, CURDATE()),' Year') as age, `admissiondate` FROM 
        `ipdadmission` INNER JOIN patient on patient.patid = ipdadmission.patientid INNER JOIN bed ON bed.bedid = ipdadmission.bedid where 1";
        string reportQuery;
        // Load Ward Patient
        async void loadWardPatient(string query)
        {
            try
            {
                dgvPatient.DataSource = await database.GetData(query);
                reportQuery = query;
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        // Search Patient
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string search = txtSearch.Text;
                string searchQuery = viewQuery + " and patient.fullname like ('%" + search + "%') or `admissionno` like ('%" + search + "%') or `admissiondate` like ('%" + search + "%')";
                loadWardPatient(searchQuery);
            }
            catch (Exception exc)
            {
                animation.notification(Color.Crimson, "Error", exc.Message);
            }
        }

        // View Discharged Patient
        private void rbDischarged_Click(object sender, EventArgs e)
        {
            loadWardPatient(viewQuery + " and ipdadmission.status='Discharged'");
        }

        // View Inward Patient
        private void rbPending_Click(object sender, EventArgs e)
        {
            loadWardPatient(viewQuery + " and ipdadmission.status='Inward'");
        }

        // View All Patient
        private void rbAll_Click(object sender, EventArgs e)
        {
            loadWardPatient(viewQuery);
        }

        //Generate report
        private void btnPrint_Click(object sender, EventArgs e)
        {
            new frmWardpatientReport(reportQuery).ShowDialog();
        }

        // Add Treatment or Medicine
        private void btnDiagnosis_Click(object sender, EventArgs e)
        {
            if (dgvPatient.SelectedRows.Count != 0)
            {
                if (status == "Inward")
                {
                    PublicClass.frmControl = new Front_Officer.frmTreatment(admissionno, patientname, false);
                    animation.changeView();
                }
                else
                {
                    PublicClass.frmControl = new Front_Officer.frmTreatment(admissionno, patientname, true);
                    animation.changeView();
                }
            }
        }

        // Discharge Patient
        private void btnDischarge_Click(object sender, EventArgs e)
        {
            if (dgvPatient.SelectedRows.Count != 0)
            {
                if (status != "Inward") animation.notification(Color.Crimson, "Failed", "The Patient already discharged");
                else
                {
                    PublicClass.frmControl = new frmDischarge(admissionno, date, bedid);
                    animation.changeView();
                }
            }
        }

        // Load Ward Patient
        private void ucWardpatient_Load(object sender, EventArgs e)
        {
            loadWardPatient(viewQuery + " and ipdadmission.status='Inward'");
        }

        private void dgvPatient_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        // Data Grid View Selection Change
        private void dgvPatient_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvPatient.SelectedRows.Count != 0)
            {
                admissionno = dgvPatient.SelectedRows[0].Cells[0].Value.ToString();
                patientname = dgvPatient.SelectedRows[0].Cells[1].Value.ToString();
                date = dgvPatient.SelectedRows[0].Cells[5].Value.ToString();
                bedid = dgvPatient.SelectedRows[0].Cells[3].Value.ToString();
                status = dgvPatient.SelectedRows[0].Cells[2].Value.ToString();
            }
        }
    }
}

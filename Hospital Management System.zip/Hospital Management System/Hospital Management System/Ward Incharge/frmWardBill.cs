﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System.Ward_Incharge
{
    public partial class frmWardBill : Form
    {
        public frmWardBill(string admissionno)
        {
            InitializeComponent();
            viewBill += " and ipdbill.admissionno='"+admissionno+"'";
        }

        string viewBill = @"SELECT `billno`, ipdbill.`admissionno`, ipdadmission.admissiondate,`roomcharge`, patient.fullname, `medcharge`, `trtcharge`, `total`, `billdate` FROM `ipdbill` 
        INNER JOIN ipdadmission on ipdadmission.admissionno=ipdbill.admissionno INNER JOIN patient ON patient.patid = ipdadmission.patientid WHERE 1";

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmWardBill_Load(object sender, EventArgs e)
        {
            dsWardBillBindingSource.DataSource = new Database().viewData(viewBill);
            this.reportViewer1.RefreshReport();
        }
    }
}
